# Pakiet Cynamonowy - NovaHouse

## Podstawowe informacje
- **Cena**: od 1999 zł/m²
- **Kategoria**: Premium

## Zawartość pakietu

### Półka cenowa produktów wykończeniowych
- ★★★★★ (premium)

### Usługa wykończenia
- malowanie
- montaż drzwi
- położenie podłogi
- łazienka kompleksowo

### Materiały budowlane i wykończeniowe
- ✓

### Projekt indywidualny
- projekt wykonawczy + lista zakupowa

### Koordynacja prac i zamówień
- w tym: raporty

## Szczegóły wykończenia

### Łazienka (wykończenie kompleksowe)
- płytki + dekor + mozaika
- dodatkowy LED
- baterie podtynkowe
- szafka na wymiar z umywalką
- lustro na wymiar premium
- WC podwieszane
- wanna wolnostojąca lub kabina z brodzikiem konglomeratowym
- oświetlenie 4 punkty

### Podłogi
- podłoga drewniana
- listwy premium

### Drzwi wewnętrzne
- skrzydła drzwiowe ukryte
- przesuwane
- drewniane

### Ściany
- malowanie ścian na wybrany kolor

## Dodatkowe rzeczy poza pakietem

### Kuchnia 3m2 m.b.
- wycena po zrobieniu projektu

### Zabudowy na wymiar (laminat)
- wycena po zrobieniu projektu

### Klimatyzacja
- wycena po zrobieniu projektu

### Schody
- wycena po zrobieniu projektu

### Gwarancja na usługi
- 3 lata
