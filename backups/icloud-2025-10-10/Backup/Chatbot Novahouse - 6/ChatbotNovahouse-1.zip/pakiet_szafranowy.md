# Pakiet Szafranowy - NovaHouse

## Podstawowe informacje
- **Cena**: od 1099 zł/m²
- **Kategoria**: Komfortowy

## Zawartość pakietu

### Półka cenowa produktów wykończeniowych
- ★★★☆☆ (średnia)

### Usługa wykończenia
- malowanie
- montaż drzwi
- położenie podłogi
- łazienka kompleksowo

### Materiały budowlane i wykończeniowe
- ✓

### Projekt indywidualny
- projekt wykonawczy + lista zakupowa

### Koordynacja prac i zamówień
- w tym: raporty

## Szczegóły wykończenia

### Łazienka (wykończenie kompleksowe)
- płytki + dekor
- WC podwieszane
- umywalka z szafką podwieszana
- lustro ozdobne lub na wymiar
- wanna lub kabina z brodzikiem
- oświetlenie 2 punkty

### Podłogi
- panele podłogowe laminowane (pokoje)
- płytki (korytarz, kuchnia)
- listwy MDF

### Drzwi wewnętrzne
- skrzydła drzwiowe
- ościeżnice
- klamki

### Ściany
- malowanie ścian na wybrany kolor

## Dodatkowe rzeczy poza pakietem

### Kuchnia 3m2 m.b.
- wycena po zrobieniu projektu

### Zabudowy na wymiar (laminat)
- wycena po zrobieniu projektu

### Klimatyzacja
- wycena po zrobieniu projektu

### Schody
- wycena po zrobieniu projektu

### Gwarancja na usługi
- 3 lata
