# Kontakt - NovaHouse

## Biuro obsługi klienta (Gdańsk, Warszawa, Wrocław)
- Telefon: 585 004 663

## Logistyka, zamówienia
- Telefon: 509 929 437

## Współpraca z partnerami, wykonawcami
- Email: partnerzy@novahouse.pl

## Finanse i Księgowość
- Telefon: 607 518 544

## Reklamacje
- Zgłoszenia przyjmowane przez formularz "Zgłoś Reklamacje"

## Adresy oddziałów

### Oddział Gdańsk
- Adres: ul. Pałubickiego 2 (budynek C2-parter), 80-175 Gdańsk
- Parking: dostępny dla gości

### Oddział Warszawa
- Adres: ul. Prosta 70 – 5 piętro, 00-838 Warszawa
- Parking: dostępny na zgłoszenie telefoniczne

### Oddział Wrocław
- Adres: ul. Sucha 3, 50-086 Wrocław

## Dane firmy
- Nazwa: NovaHouse Sp. z o.o.
- KRS: 0000612864
- NIP: 5833201699
- REGON: 364323586
- Kapitał zakładowy: 100.000,00 PLN
