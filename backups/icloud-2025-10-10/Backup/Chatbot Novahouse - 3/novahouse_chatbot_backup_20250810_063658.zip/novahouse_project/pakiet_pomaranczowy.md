# Pakiet Pomarańczowy - NovaHouse

## Podstawowe informacje
- **Cena**: od 1399 zł/m²
- **Kategoria**: Podwyższony

## Zawartość pakietu

### Półka cenowa produktów wykończeniowych
- ★★★★☆ (podwyższona)

### Usługa wykończenia
- malowanie
- montaż drzwi
- położenie podłogi
- łazienka kompleksowo

### Materiały budowlane i wykończeniowe
- ✓

### Projekt indywidualny
- projekt wykonawczy + lista zakupowa

### Koordynacja prac i zamówień
- w tym: raporty

## Szczegóły wykończenia

### Łazienka (wykończenie kompleksowe)
- płytki + dekor + mozaika
- dodatkowy LED
- lustro na wymiar
- umywalka z szafką podwieszana
- WC podwieszane
- wanna lub kabina z brodzikiem konglomeratowym
- oświetlenie 3 punkty

### Podłogi
- panele laminowane
- winylowe lub płytki
- listwy wodoodporne

### Drzwi wewnętrzne
- skrzydła drzwiowe bezprzylgowe
- ościeżnice bezprzylgowe (chowane zawiasy)

### Ściany
- malowanie ścian na wybrany kolor

## Dodatkowe rzeczy poza pakietem

### Kuchnia 3m2 m.b.
- wycena po zrobieniu projektu

### Zabudowy na wymiar (laminat)
- wycena po zrobieniu projektu

### Klimatyzacja
- wycena po zrobieniu projektu

### Schody
- wycena po zrobieniu projektu

### Gwarancja na usługi
- 3 lata
