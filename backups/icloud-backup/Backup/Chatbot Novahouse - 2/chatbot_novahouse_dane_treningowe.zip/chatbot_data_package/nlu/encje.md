# Encje dla chatbota NovaHouse

## pakiet_wykonczeniowy
- waniliowy
- szafranowy
- pomarańczowy
- cynamonowy
- indywidualny
- podstawowy
- komfortowy
- podwyższony
- premium
- standardowy
- ekonomiczny
- luksusowy

## metraz_lokalu
- 20m2
- 30m2
- 35m2
- 40m2
- 45m2
- 50m2
- 55m2
- 60m2
- 65m2
- 70m2
- 75m2
- 80m2
- 85m2
- 90m2
- 100m2
- 120m2
- 140m2
- 150m2
- 200m2
- kawalerka
- studio
- dwupokojowe
- trzypokojowe
- czteropokojowe

## typ_nieruchomosci
- mieszkanie
- dom
- apartament
- kawalerka
- studio
- dom jednorodzinny
- dom pasywny
- dom energooszczędny
- szeregowiec
- bliźniak
- loft
- penthouse
- kamienica
- lokal usługowy
- biuro
- powierzchnia komercyjna

## miasto
- Gdańsk
- Warszawa
- Wrocław
- Trójmiasto
- Sopot
- Gdynia
- okolice Gdańska
- okolice Warszawy
- okolice Wrocławia
- aglomeracja warszawska
- aglomeracja trójmiejska
- aglomeracja wrocławska
- województwo pomorskie
- województwo mazowieckie
- województwo dolnośląskie

## element_wykonczenia
- łazienka
- kuchnia
- salon
- sypialnia
- przedpokój
- korytarz
- garderoba
- podłoga
- ściany
- sufit
- drzwi
- okna
- płytki
- panele
- farba
- tapeta
- oświetlenie
- armatura
- meble
- zabudowa
- szafa
- klimatyzacja
- ogrzewanie
- elektryka
- hydraulika
- wentylacja
- schody
- balkon
- taras
