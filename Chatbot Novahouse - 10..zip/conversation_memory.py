"""
Conversation Memory Module - Enhanced conversation history management for GPT
Ensures GPT has full context of the conversation history
"""

import json
from datetime import datetime


def safe_log(message):
    """Safely log a message, handling missing app context"""
    try:
        from flask import current_app
        current_app.logger.info(message)
    except (RuntimeError, ImportError):
        # No app context or Flask not available - skip logging
        pass


def safe_log_error(message):
    """Safely log an error, handling missing app context"""
    try:
        from flask import current_app
        current_app.logger.error(message)
    except (RuntimeError, ImportError):
        # No app context or Flask not available - skip logging
        pass


class ConversationMemory:
    """Manages conversation history for GPT context"""
    
    def __init__(self, max_messages=10):
        """
        Initialize conversation memory
        
        Args:
            max_messages: Maximum number of messages to keep in history (default: 10 = 5 exchanges)
        """
        self.max_messages = max_messages
    
    def get_conversation_history(self, session_id):
        """
        Get conversation history for a session in GPT message format
        
        Args:
            session_id: Session identifier
            
        Returns:
            List of messages in format [{"role": "user/assistant", "content": "..."}]
        """
        try:
            from src.models.chatbot import SessionContext
            
            # Get session context from database
            session_context = SessionContext.query.filter_by(session_id=session_id).first()
            
            if not session_context:
                return []
            
            # Parse context data
            context_data = json.loads(session_context.context_data)
            
            # Get conversation history
            conversation_history = context_data.get('conversation_history', [])
            
            # Return last N messages
            if len(conversation_history) > self.max_messages:
                return conversation_history[-self.max_messages:]
            
            return conversation_history
            
        except Exception as e:
            safe_log_error(f"Error getting conversation history: {e}")
            return []
    
    def add_message(self, session_id, role, content):
        """
        Add a message to conversation history
        
        Args:
            session_id: Session identifier
            role: "user" or "assistant"
            content: Message content
        """
        try:
            from src.models.chatbot import SessionContext
            from src.models.user import db
            
            # Get or create session context
            session_context = SessionContext.query.filter_by(session_id=session_id).first()
            
            if not session_context:
                # Create new context
                context_data = {
                    "session_id": session_id,
                    "conversation_history": [],
                    "encje": {},
                    "historia": [],
                    "created_at": datetime.now().isoformat()
                }
                session_context = SessionContext(
                    session_id=session_id,
                    context_data=json.dumps(context_data, ensure_ascii=False)
                )
                db.session.add(session_context)
            else:
                context_data = json.loads(session_context.context_data)
            
            # Add message to conversation history
            if "conversation_history" not in context_data:
                context_data["conversation_history"] = []
            
            context_data["conversation_history"].append({
                "role": role,
                "content": content,
                "timestamp": datetime.now().isoformat()
            })
            
            # Limit history size
            if len(context_data["conversation_history"]) > self.max_messages:
                context_data["conversation_history"] = context_data["conversation_history"][-self.max_messages:]
            
            # Save to database
            session_context.context_data = json.dumps(context_data, ensure_ascii=False)
            session_context.last_updated = datetime.now()
            db.session.commit()
            
        except Exception as e:
            safe_log_error(f"Error adding message to history: {e}")
    
    def update_entities(self, session_id, entities):
        """
        Update entities in session context
        
        Args:
            session_id: Session identifier
            entities: Dictionary of entities to update
        """
        try:
            from src.models.chatbot import SessionContext
            from src.models.user import db
            
            session_context = SessionContext.query.filter_by(session_id=session_id).first()
            
            if not session_context:
                return
            
            context_data = json.loads(session_context.context_data)
            
            # Update entities
            if "encje" not in context_data:
                context_data["encje"] = {}
            
            for key, value in entities.items():
                if value:  # Only non-empty values
                    context_data["encje"][key] = value
            
            # Save to database
            session_context.context_data = json.dumps(context_data, ensure_ascii=False)
            session_context.last_updated = datetime.now()
            db.session.commit()
            
        except Exception as e:
            safe_log_error(f"Error updating entities: {e}")
    
    def get_entities(self, session_id):
        """
        Get all collected entities for a session
        
        Args:
            session_id: Session identifier
            
        Returns:
            Dictionary of entities
        """
        try:
            from src.models.chatbot import SessionContext
            
            session_context = SessionContext.query.filter_by(session_id=session_id).first()
            
            if not session_context:
                return {}
            
            context_data = json.loads(session_context.context_data)
            return context_data.get('encje', {})
            
        except Exception as e:
            safe_log_error(f"Error getting entities: {e}")
            return {}
    
    def build_gpt_messages(self, session_id, system_prompt, current_message):
        """
        Build complete message list for GPT including system prompt, history, and current message
        
        Args:
            session_id: Session identifier
            system_prompt: System prompt for GPT
            current_message: Current user message
            
        Returns:
            List of messages ready for GPT API
        """
        messages = [
            {"role": "system", "content": system_prompt}
        ]
        
        # Add conversation history
        history = self.get_conversation_history(session_id)
        
        # Remove timestamps from history (GPT doesn't need them)
        for msg in history:
            messages.append({
                "role": msg["role"],
                "content": msg["content"]
            })
        
        # Add current message
        messages.append({
            "role": "user",
            "content": current_message
        })
        
        return messages
    
    def get_context_summary(self, session_id):
        """
        Get a human-readable summary of the conversation context
        
        Args:
            session_id: Session identifier
            
        Returns:
            String with context summary
        """
        try:
            entities = self.get_entities(session_id)
            history = self.get_conversation_history(session_id)
            
            summary = "\n\nKONTEKST POPRZEDNIEJ ROZMOWY:"
            
            # Add collected entities
            if entities:
                summary += "\n\nZebrane informacje o kliencie:"
                
                entity_labels = {
                    'metraz_mieszkania': 'Metraż',
                    'budżet_klienta': 'Budżet',
                    'budzet_klienta': 'Budżet',
                    'lokalizacja': 'Lokalizacja',
                    'lokalizacja_miasta': 'Lokalizacja',
                    'numer_telefonu': 'Telefon',
                    'email': 'Email',
                    'imie_klienta': 'Imię',
                    'typ_pakietu': 'Interesujący pakiet',
                    'pakiet_wykonczeniowy': 'Interesujący pakiet',
                    'typ_nieruchomosci': 'Typ nieruchomości',
                    'stan_mieszkania': 'Stan mieszkania',
                    'termin_realizacji': 'Termin realizacji'
                }
                
                for key, value in entities.items():
                    label = entity_labels.get(key, key)
                    summary += f"\n- {label}: {value}"
            
            # Add conversation summary
            if history:
                summary += f"\n\nHistoria rozmowy: {len(history)} wiadomości"
                
                # Add last 2 exchanges
                recent = history[-4:] if len(history) >= 4 else history
                if recent:
                    summary += "\n\nOstatnie wiadomości:"
                    for msg in recent:
                        role_label = "Klient" if msg["role"] == "user" else "Bot"
                        content_preview = msg["content"][:100]
                        if len(msg["content"]) > 100:
                            content_preview += "..."
                        summary += f"\n- {role_label}: {content_preview}"
            
            summary += "\n\nPAMIĘTAJ: Wykorzystaj te informacje, nie pytaj ponownie o to co już wiesz!"
            
            return summary
            
        except Exception as e:
            safe_log_error(f"Error building context summary: {e}")
            return ""
    
    def clear_history(self, session_id):
        """
        Clear conversation history for a session
        
        Args:
            session_id: Session identifier
        """
        try:
            from src.models.chatbot import SessionContext
            from src.models.user import db
            
            session_context = SessionContext.query.filter_by(session_id=session_id).first()
            
            if session_context:
                context_data = json.loads(session_context.context_data)
                context_data["conversation_history"] = []
                context_data["historia"] = []
                
                session_context.context_data = json.dumps(context_data, ensure_ascii=False)
                db.session.commit()
                
        except Exception as e:
            safe_log_error(f"Error clearing history: {e}")


# Global instance
conversation_memory = ConversationMemory(max_messages=10)

