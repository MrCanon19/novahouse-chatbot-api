# 🚀 KARTA SZYBKIEGO DOSTĘPU - NOVAHOUSE CHATBOT

## 🌐 LINKI

### Panel Administracyjny
```
https://glass-core-467907-e9.ey.r.appspot.com/static/admin.html
```

### API Endpoints
```
# Health check
https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/health

# Statystyki
https://glass-core-467907-e9.ey.r.appspot.com/api/analytics/stats

# Rozmowy
https://glass-core-467907-e9.ey.r.appspot.com/api/analytics/conversations

# Intencje
https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/intents

# Encje
https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/entities
```

---

## 📊 AKTUALNE STATYSTYKI

- **Rozmowy:** 67
- **Intencje:** 24
- **Encje:** 15
- **Leady:** 0
- **Wersja:** 20251003t012135

---

## 🔧 KOMENDY GCP

### Wdrożenie nowej wersji
```bash
cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api
gcloud app deploy app.yaml --quiet --project glass-core-467907-e9
```

### Sprawdź wersje
```bash
gcloud app versions list --project glass-core-467907-e9
```

### Sprawdź aktywną wersję
```bash
gcloud app versions list --project glass-core-467907-e9 --filter="TRAFFIC_SPLIT>0"
```

### Logi na żywo
```bash
gcloud app logs tail -s default --project glass-core-467907-e9
```

### Ostatnie logi
```bash
gcloud app logs read --limit=50 --project glass-core-467907-e9 --service=default
```

### Rollback do poprzedniej wersji
```bash
gcloud app versions migrate [PREVIOUS_VERSION_ID] --project glass-core-467907-e9
```

---

## 🗄️ BAZA DANYCH

### Dane połączenia
```
Host: 35.205.83.191
Database: chatbot_db
User: chatbot_user
Password: NovaHouse2024SecurePass
```

### Sprawdź bazę danych
```bash
python3.11 /home/ubuntu/check_database.py
```

### Połącz się z bazą (psql)
```bash
psql -h 35.205.83.191 -U chatbot_user -d chatbot_db
```

---

## 🔍 DIAGNOSTYKA

### Test wszystkich endpointów
```bash
# Health
curl https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/health

# Stats
curl https://glass-core-467907-e9.ey.r.appspot.com/api/analytics/stats | jq

# Conversations (pierwsze 2)
curl https://glass-core-467907-e9.ey.r.appspot.com/api/analytics/conversations | jq '.[0:2]'

# Intents (pierwsze 3)
curl https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/intents | jq '.[0:3]'

# Entities (pierwsze 3)
curl https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/entities | jq '.[0:3]'
```

### Sprawdź status aplikacji
```bash
gcloud app describe --project glass-core-467907-e9
```

### Sprawdź użycie zasobów
```bash
gcloud app instances list --project glass-core-467907-e9
```

---

## 🔐 MONDAY.COM

### Konfiguracja
```
Board ID: 2145240699
Board Name: Chat
Group ID: leady_z_chatbota
API Key: (w zmiennych środowiskowych GCP)
```

### Test integracji
Wyślij wiadomość do chatbota z danymi kontaktowymi:
```
"Chcę umówić spotkanie. Jestem Jan Kowalski, telefon 123456789, email jan@test.pl"
```

Lead powinien pojawić się na tablicy Monday.com w grupie "leady_z_chatbota".

---

## 📁 STRUKTURA PROJEKTU

```
/home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api/
├── app.yaml                    # Konfiguracja GCP App Engine
├── requirements.txt            # Zależności Python
├── main.py                     # Punkt wejścia aplikacji
└── src/
    ├── main.py                 # Główna aplikacja Flask
    ├── models/
    │   ├── chatbot.py         # Modele: Intent, Entity, Conversation
    │   └── user.py            # Model User i db
    ├── routes/
    │   ├── chatbot.py         # Endpointy chatbota
    │   └── analytics_routes.py # Endpointy analityki
    ├── static/
    │   ├── admin.html         # Panel administracyjny
    │   └── admin.js           # JavaScript panelu admin
    ├── monday_integration.py   # Integracja Monday.com
    └── intelligent_expert.py   # Logika chatbota z GPT-4o-mini
```

---

## ⚡ SZYBKIE AKCJE

### Restart aplikacji
```bash
# Wdróż tę samą wersję ponownie
gcloud app deploy app.yaml --quiet --project glass-core-467907-e9
```

### Wyczyść cache przeglądarki
```
Ctrl + Shift + R (Chrome/Firefox)
Cmd + Shift + R (Mac)
```

### Sprawdź czy aplikacja działa
```bash
curl -I https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/health
```

Oczekiwany wynik: `HTTP/2 200`

---

## 🐛 TROUBLESHOOTING

### Problem: Panel admin nie ładuje danych
1. Sprawdź logi: `gcloud app logs tail -s default --project glass-core-467907-e9`
2. Sprawdź endpoint bezpośrednio: `curl https://glass-core-467907-e9.ey.r.appspot.com/api/analytics/conversations`
3. Wyczyść cache przeglądarki: Ctrl + Shift + R

### Problem: Błąd 500 na endpoincie
1. Sprawdź logi GCP: `gcloud app logs read --limit=30 --project glass-core-467907-e9`
2. Sprawdź bazę danych: `python3.11 /home/ubuntu/check_database.py`
3. Sprawdź czy wszystkie zmienne środowiskowe są ustawione w `app.yaml`

### Problem: Chatbot nie odpowiada
1. Sprawdź health: `curl https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/health`
2. Sprawdź czy OpenAI API key jest ustawiony
3. Sprawdź logi pod kątem błędów GPT

### Problem: Leady nie trafiają do Monday.com
1. Sprawdź czy Board ID i Group ID są poprawne
2. Sprawdź czy API key Monday.com jest ustawiony
3. Sprawdź logi pod kątem błędów Monday API
4. Zweryfikuj uprawnienia API key na Monday.com

---

## 📞 KONTAKT I WSPARCIE

### Dokumentacja
- **Raport końcowy:** `/home/ubuntu/RAPORT_KONCOWY_NAPRAWY.md`
- **Instrukcja wdrożenia:** `/home/ubuntu/POPRAWKI_WDROZENIE_FINAL.md`
- **Checklist:** `/home/ubuntu/CHECKLIST_WDROZENIA.md`

### Backup
```bash
# Lokalizacja backupu
/home/ubuntu/novahouse_chatbot_poprawki_20251001.tar.gz

# Rozpakuj backup
tar -xzf /home/ubuntu/novahouse_chatbot_poprawki_20251001.tar.gz
```

---

## ✅ STATUS SYSTEMU

| Komponent | Status | Uwagi |
|-----------|--------|-------|
| Panel Admin | ✅ DZIAŁA | Wszystkie zakładki oprócz bazy wiedzy |
| Dashboard | ✅ DZIAŁA | Statystyki wyświetlane poprawnie |
| Rozmowy | ✅ DZIAŁA | 67 rozmów widocznych |
| Intencje | ✅ DZIAŁA | 24 intencje z przykładami |
| Encje | ✅ DZIAŁA | 15 encji z wartościami |
| Baza wiedzy | ⚠️ OPCJONALNE | Wymaga wdrożenia pliku |
| API Endpoints | ✅ DZIAŁA | Wszystkie 6 endpointów |
| Baza danych | ✅ DZIAŁA | PostgreSQL na GCP |
| Monday.com | ✅ DZIAŁA | Integracja skonfigurowana |
| Chatbot GPT | ✅ DZIAŁA | GPT-4o-mini zintegrowany |

---

**Ostatnia aktualizacja:** 3 października 2025, 05:25 UTC  
**Wersja karty:** 1.0  
**Aktualna wersja GCP:** 20251003t012135
