#!/bin/bash
# Comprehensive Deployment Script for NovaHouse Chatbot
# Run this on your local machine with GCP access

set -e  # Exit on error

echo "🚀 NovaHouse Chatbot - Comprehensive Deployment"
echo "================================================"
echo ""

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Configuration
PROJECT_ID="glass-core-467907-e9"
APP_DIR="/home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api"

echo -e "${YELLOW}Step 1: Checking GCP authentication...${NC}"
if ! gcloud auth list 2>&1 | grep -q "ACTIVE"; then
    echo -e "${RED}Not authenticated. Running: gcloud auth login${NC}"
    gcloud auth login
fi

echo -e "${GREEN}✓ Authenticated${NC}"
echo ""

echo -e "${YELLOW}Step 2: Setting project...${NC}"
gcloud config set project $PROJECT_ID
echo -e "${GREEN}✓ Project set to $PROJECT_ID${NC}"
echo ""

echo -e "${YELLOW}Step 3: Checking directory...${NC}"
if [ ! -d "$APP_DIR" ]; then
    echo -e "${RED}Error: Directory $APP_DIR not found${NC}"
    exit 1
fi
cd $APP_DIR
echo -e "${GREEN}✓ Directory OK${NC}"
echo ""

echo -e "${YELLOW}Step 4: Deploying to App Engine...${NC}"
gcloud app deploy app.yaml --quiet --project=$PROJECT_ID
echo -e "${GREEN}✓ Deployment successful!${NC}"
echo ""

echo -e "${YELLOW}Step 5: Testing endpoints...${NC}"
BASE_URL="https://glass-core-467907-e9.ey.r.appspot.com"

# Test health
echo "Testing /api/chatbot/health..."
curl -s "$BASE_URL/api/chatbot/health" | python3 -m json.tool || echo "Health check failed"

# Test dashboard metrics
echo "Testing /api/dashboard/metrics..."
curl -s "$BASE_URL/api/dashboard/metrics" | python3 -m json.tool | head -20 || echo "Metrics failed"

# Test recommendations
echo "Testing /api/recommendations/packages..."
curl -s "$BASE_URL/api/recommendations/packages" | python3 -m json.tool | head -20 || echo "Recommendations failed"

echo ""
echo -e "${GREEN}✓ All tests completed${NC}"
echo ""

echo "================================================"
echo -e "${GREEN}🎉 Deployment Complete!${NC}"
echo ""
echo "URLs:"
echo "  - App: $BASE_URL"
echo "  - Admin Panel: $BASE_URL/static/admin.html"
echo "  - Health: $BASE_URL/api/chatbot/health"
echo "  - Dashboard: $BASE_URL/api/dashboard/metrics"
echo ""
echo "Next steps:"
echo "  1. Open admin panel and verify all tabs work"
echo "  2. Test chatbot with a conversation"
echo "  3. Check logs: gcloud app logs tail -s default"
echo ""
