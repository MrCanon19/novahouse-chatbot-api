# 🚀 WDROŻENIE NovaHouse Chatbot v2.0 - INSTRUKCJA

## ✅ STAN OBECNY

**System na GCP:**
- URL: https://glass-core-467907-e9.ey.r.appspot.com
- Status: ✅ DZIAŁA (health check OK)
- Problem: ❌ Readonly database (nie zapisuje konwersacji)

**Nowe funkcje gotowe do wdrożenia:**
- ✅ Conversation Memory (conversation_memory.py)
- ✅ Intent-Driven Actions (intent_actions.py)
- ✅ Zaktualizowany chatbot.py z integracją

---

## 🎯 CO ZROBI WDROŻENIE

1. **Naprawi problem z bazą danych**
   - System będzie używał PostgreSQL z Cloud SQL
   - Konwersacje będą zapisywane poprawnie

2. **Doda nowe funkcje AI**
   - Conversation Memory (pamięć kontekstu)
   - Intent-Driven Actions (automatyczne akcje)

3. **Zaktualizuje frontend**
   - Poprawi URL endpointów
   - Zapewni poprawną komunikację

---

## 📋 KROKI WDROŻENIA

### Krok 1: Autoryzacja GCP

```bash
gcloud auth login
```

### Krok 2: Wdrożenie

```bash
cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api

gcloud config set project glass-core-467907-e9

gcloud app deploy app.yaml --quiet
```

### Krok 3: Weryfikacja

```bash
# Test 1: Health check
curl https://glass-core-467907-e9.ey.r.appspot.com/api/health

# Test 2: Chatbot (powinien zapisać konwersację bez błędu)
curl -X POST https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Cześć","session_id":"test123"}'

# Test 3: Conversation Memory (2 wiadomości w tej samej sesji)
curl -X POST https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Mam 60m2 i budżet 120k","session_id":"memory_test"}'

curl -X POST https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"A ile to będzie kosztować?","session_id":"memory_test"}'
# Bot powinien pamiętać metraż i budżet!
```

---

## 🔍 OCZEKIWANE REZULTATY

### Po wdrożeniu:

1. **Brak błędu "readonly database"**
   - Konwersacje zapisują się do PostgreSQL

2. **Conversation Memory działa**
   - Bot pamięta kontekst rozmowy
   - Nie pyta ponownie o te same informacje

3. **Intent-Driven Actions działają**
   - Bot automatycznie umawia spotkania
   - Bot generuje wyceny
   - Bot tworzy leady w Monday.com

4. **Frontend działa**
   - chatbot.html odpowiada na wiadomości
   - Brak błędów w konsoli przeglądarki

---

## 🐛 TROUBLESHOOTING

### Jeśli nadal błąd "readonly database":

```bash
# Sprawdź logi
gcloud app logs tail -s default --limit 50

# Sprawdź czy DATABASE_URL jest używany
gcloud app logs tail -s default | grep DATABASE
```

### Jeśli Cloud SQL nie działa:

```bash
# Sprawdź status Cloud SQL
gcloud sql instances describe novahouse-chatbot-db

# Sprawdź połączenie
gcloud sql connect novahouse-chatbot-db --user=chatbot_user
```

### Jeśli frontend nie działa:

```bash
# Otwórz w przeglądarce i sprawdź Console (F12)
open https://glass-core-467907-e9.ey.r.appspot.com/static/chatbot.html
```

---

## 📊 CHECKLIST

- [ ] Zalogowano do GCP
- [ ] Ustawiono projekt (glass-core-467907-e9)
- [ ] Wdrożono aplikację
- [ ] Test health check (200 OK)
- [ ] Test chatbot (brak błędu database)
- [ ] Test conversation memory (2 wiadomości)
- [ ] Test w przeglądarce (chatbot.html)
- [ ] Sprawdzono logi (brak błędów)

---

## 🎉 SUKCES

Gdy wszystkie testy przejdą:
- ✅ System działa bez błędów
- ✅ Conversation Memory aktywna
- ✅ Intent-Driven Actions aktywne
- ✅ Baza danych zapisuje poprawnie

**Chatbot NovaHouse v2.0 jest live!** 🚀

---

*Czas wdrożenia: 5-10 minut*
*Przygotował: Manus AI*
*Data: 10 października 2025*

