/**
 * Panel administracyjny NovaHouse - naprawiona wersja
 */

document.addEventListener("DOMContentLoaded", function() {
    const API_BASE_URL = "/api";

    // Funkcje pomocnicze
    const fetchData = async (endpoint) => {
        try {
            const response = await fetch(`${API_BASE_URL}${endpoint}`);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error(`Fetch error for ${endpoint}:`, error);
            return [];
        }
    };

    // Ładowanie rozmów
    const loadConversations = async () => {
        console.log("Ładowanie rozmów...");
        const conversations = await fetchData("/analytics/conversations");
        console.log("Pobrane rozmowy:", conversations);
        
        const tableBody = document.getElementById("conversations-table");
        if (!tableBody) {
            console.error("Nie znaleziono elementu conversations-table");
            return;
        }
        
        if (conversations && conversations.length > 0) {
            tableBody.innerHTML = conversations.map(c => `
                <tr>
                    <td>${c.session_id ? c.session_id.substring(0, 8) : 'N/A'}</td>
                    <td style="max-width: 200px; overflow: hidden; text-overflow: ellipsis;">${c.user_message || 'N/A'}</td>
                    <td style="max-width: 300px; overflow: hidden; text-overflow: ellipsis;">${c.bot_response || 'N/A'}</td>
                    <td>${c.intent || 'N/A'}</td>
                    <td>${c.timestamp ? new Date(c.timestamp).toLocaleString('pl-PL') : 'N/A'}</td>
                </tr>
            `).join('');
            console.log(`Załadowano ${conversations.length} rozmów`);
        } else {
            tableBody.innerHTML = '<tr><td colspan="5" class="text-center">Brak rozmów</td></tr>';
        }
    };

    // Ładowanie intencji
    const loadIntents = async () => {
        console.log("Ładowanie intencji...");
        const intents = await fetchData("/chatbot/intents");
        console.log("Pobrane intencje:", intents);
        
        const tableBody = document.getElementById("intents-table");
        if (!tableBody) {
            console.error("Nie znaleziono elementu intents-table");
            return;
        }
        
        if (intents && intents.length > 0) {
            tableBody.innerHTML = intents.map(i => `
                <tr>
                    <td>${i.name || 'N/A'}</td>
                    <td style="max-width: 400px; overflow: hidden; text-overflow: ellipsis;">${
                        i.training_phrases ? i.training_phrases.slice(0, 3).join(', ') + (i.training_phrases.length > 3 ? '...' : '') : 'N/A'
                    }</td>
                    <td><button class="btn btn-sm btn-warning">Edytuj</button></td>
                </tr>
            `).join('');
            console.log(`Załadowano ${intents.length} intencji`);
        } else {
            tableBody.innerHTML = '<tr><td colspan="3" class="text-center">Brak intencji</td></tr>';
        }
    };

    // Ładowanie encji
    const loadEntities = async () => {
        console.log("Ładowanie encji...");
        const entities = await fetchData("/chatbot/entities");
        console.log("Pobrane encje:", entities);
        
        const tableBody = document.getElementById("entities-table");
        if (!tableBody) {
            console.error("Nie znaleziono elementu entities-table");
            return;
        }
        
        if (entities && entities.length > 0) {
            tableBody.innerHTML = entities.map(e => `
                <tr>
                    <td>${e.name || 'N/A'}</td>
                    <td style="max-width: 400px; overflow: hidden; text-overflow: ellipsis;">${
                        e.values ? e.values.slice(0, 5).join(', ') + (e.values.length > 5 ? '...' : '') : 'N/A'
                    }</td>
                    <td><button class="btn btn-sm btn-warning">Edytuj</button></td>
                </tr>
            `).join('');
            console.log(`Załadowano ${entities.length} encji`);
        } else {
            tableBody.innerHTML = '<tr><td colspan="3" class="text-center">Brak encji</td></tr>';
        }
    };

    // Ładowanie bazy wiedzy
    const loadKnowledgeBase = async () => {
        console.log("Ładowanie bazy wiedzy...");
        const knowledge = await fetchData("/chatbot/knowledge");
        const textarea = document.getElementById("knowledge-base-content");
        if (textarea) {
            textarea.value = knowledge.content || 'Baza wiedzy nie jest dostępna';
        }
    };

    // Ładowanie dashboardu
    const loadDashboard = async () => {
        console.log("Ładowanie dashboardu...");
        const stats = await fetchData("/analytics/stats");
        console.log("Statystyki:", stats);
        
        const dashboardContent = document.getElementById("analytics-dashboard-content");
        if (dashboardContent) {
            dashboardContent.innerHTML = `
                <div class="row">
                    <div class="col-md-3">
                        <div class="card text-white bg-primary">
                            <div class="card-body">
                                <h5 class="card-title">Rozmowy</h5>
                                <h2>${stats.total_conversations || 0}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-success">
                            <div class="card-body">
                                <h5 class="card-title">Intencje</h5>
                                <h2>${stats.total_intents || 0}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-info">
                            <div class="card-body">
                                <h5 class="card-title">Encje</h5>
                                <h2>${stats.total_entities || 0}</h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card text-white bg-warning">
                            <div class="card-body">
                                <h5 class="card-title">Dzisiaj</h5>
                                <h2>${stats.today_conversations || 0}</h2>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h5>Ostatnie rozmowy</h5>
                            </div>
                            <div class="card-body" id="recent-conversations">
                                Ładowanie...
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Załaduj ostatnie rozmowy do dashboardu
            loadRecentConversations();
        }
    };

    // Ładowanie ostatnich rozmów do dashboardu
    const loadRecentConversations = async () => {
        const conversations = await fetchData("/analytics/conversations");
        const recentDiv = document.getElementById("recent-conversations");
        if (recentDiv && conversations && conversations.length > 0) {
            const recent = conversations.slice(0, 5);
            recentDiv.innerHTML = recent.map(c => `
                <div class="border-bottom pb-2 mb-2">
                    <small class="text-muted">${c.timestamp ? new Date(c.timestamp).toLocaleString('pl-PL') : 'N/A'}</small><br>
                    <strong>Użytkownik:</strong> ${c.user_message || 'N/A'}<br>
                    <strong>Bot:</strong> ${c.bot_response ? c.bot_response.substring(0, 100) + '...' : 'N/A'}
                </div>
            `).join('');
        } else if (recentDiv) {
            recentDiv.innerHTML = '<p class="text-muted">Brak rozmów</p>';
        }
    };

    // Obsługa zakładek
    const handleTabChange = (event) => {
        const targetId = event.target.getAttribute('href');
        console.log("Zmiana zakładki na:", targetId);
        
        switch(targetId) {
            case '#dashboard':
                loadDashboard();
                break;
            case '#conversations':
                loadConversations();
                break;
            case '#intents':
                loadIntents();
                break;
            case '#entities':
                loadEntities();
                break;
            case '#knowledge':
                loadKnowledgeBase();
                break;
        }
    };

    // Inicjalizacja
    const initAdminPanel = () => {
        console.log("Inicjalizacja panelu administracyjnego...");
        
        // Dodaj event listenery do zakładek
        const tabs = document.querySelectorAll('.nav-link');
        tabs.forEach(tab => {
            tab.addEventListener('click', handleTabChange);
        });
        
        // Załaduj dashboard na start
        loadDashboard();
        
        console.log("Panel administracyjny zainicjalizowany");
    };

    // Uruchom inicjalizację
    initAdminPanel();
});
