# 🚀 SZYBKA KARTA REFERENCJI - NOVAHOUSE CHATBOT

## 📌 PODSTAWOWE INFORMACJE

**URL Aplikacji:** https://glass-core-467907-e9.ey.r.appspot.com  
**Panel Admin:** https://glass-core-467907-e9.ey.r.appspot.com/static/admin.html  
**Wersja:** 20251003t181502  
**Status:** ✅ WSZYSTKO DZIAŁA

---

## 🎯 CO ZOSTAŁO NAPRAWIONE

| Problem | Status | Opis |
|---------|--------|------|
| Admin panel - pusta tabela rozmów | ✅ | Zmieniono event z `shown.bs.tab` na `click` |
| Brakujący endpoint /api/analytics/stats | ✅ | Dodano endpoint ze statystykami |
| Brakujące endpointy intencji/encji | ✅ | Dodano 4 nowe endpointy |
| Błąd 500 przy ładowaniu | ✅ | Naprawiono obsługę None w to_dict() |
| Encje "[object Object]" | ✅ | Dodano inteligentne parsowanie obiektów |
| Baza wiedzy niedostępna | ✅ | Wdrożono plik (6.6KB) |
| Leady nie zapisują się | ✅ | Dodano zapis do bazy + Monday.com |
| Brak zakładki Leady | ✅ | Dodano pełną funkcjonalność |

---

## 📊 STATYSTYKI

- **Rozmowy:** 69
- **Intencje:** 24
- **Encje:** 15
- **Leady:** 2
- **Wdrożenia:** 4
- **Naprawione pliki:** 12

---

## 🔗 ENDPOINTY API

### Chatbot
- `POST /api/chatbot/chat` - Wysyłanie wiadomości
- `GET /api/chatbot/intents` - Lista intencji
- `GET /api/chatbot/entities` - Lista encji
- `GET /api/chatbot/knowledge` - Baza wiedzy
- `POST /api/chatbot/knowledge` - Aktualizacja bazy

### Analytics
- `GET /api/analytics/stats` - Statystyki
- `GET /api/analytics/conversations` - Rozmowy
- `GET /api/analytics/leads` - Leady

### System
- `GET /api/health` - Status aplikacji

---

## 🛠️ SZYBKIE KOMENDY

### Wdrożenie
```bash
cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api
gcloud app deploy app.yaml --quiet --project glass-core-467907-e9
```

### Logi
```bash
gcloud app logs tail -s default --project glass-core-467907-e9
```

### Status
```bash
curl https://glass-core-467907-e9.ey.r.appspot.com/api/health
```

### Sprawdź bazę
```bash
python3.11 /home/ubuntu/check_database.py
```

---

## 📁 WAŻNE PLIKI

### Backend
- `src/routes/chatbot.py` - Endpointy chatbota + zapis leadów
- `src/routes/analytics_routes.py` - Endpointy analytics
- `src/models/chatbot.py` - Modele danych
- `src/monday_lead_creator.py` - Integracja Monday.com

### Frontend
- `src/static/admin.html` - Panel admin (HTML)
- `src/static/admin.js` - Panel admin (JavaScript)

### Dokumentacja
- `PROGRAM_MAKSYMALNEJ_SATYSFAKCJI_KLIENTA.md` - Baza wiedzy

---

## 🧪 TEST CHATBOTA

```python
import requests

response = requests.post(
    "https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/chat",
    json={
        "message": "Chcę umówić spotkanie. Telefon 555666777",
        "session_id": "test_123"
    }
)
print(response.json())
```

---

## 🗄️ BAZA DANYCH

**Host:** 35.205.83.191  
**Database:** chatbot_db  
**User:** chatbot_user

### Tabele:
- `conversations` - Historia rozmów
- `intents` - Intencje (24)
- `entities` - Encje (15)
- `leads` - Leady

---

## 🔧 MONDAY.COM

**Board ID:** 2145240699 (Chat)  
**Group ID:** leady_z_chatbota  
**API Key:** Skonfigurowany w app.yaml

---

## ✅ CHECKLIST DZIAŁANIA

- [x] Dashboard ładuje statystyki
- [x] Rozmowy widoczne (69)
- [x] Leady widoczne (2)
- [x] Intencje widoczne (24)
- [x] Encje widoczne (15) - bez "[object Object]"
- [x] Baza wiedzy załadowana
- [x] Chatbot rozpoznaje intencje
- [x] Chatbot wydobywa encje
- [x] Leady zapisują się do bazy
- [x] Leady wysyłają się do Monday.com
- [x] Brak błędów w konsoli

---

## 🚨 TROUBLESHOOTING

### Problem: Panel admin nie ładuje danych
**Rozwiązanie:** Otwórz konsolę (F12), sprawdź błędy, odśwież stronę

### Problem: Chatbot nie odpowiada
**Rozwiązanie:** Sprawdź logi `gcloud app logs tail -s default`

### Problem: Leady nie zapisują się
**Rozwiązanie:** Sprawdź bazę danych `/home/ubuntu/check_database.py`

### Problem: Błąd 500
**Rozwiązanie:** Sprawdź logi GCP, może być problem z bazą danych

---

## 📞 WSPARCIE

1. Sprawdź logi GCP
2. Sprawdź konsolę przeglądarki
3. Sprawdź bazę danych
4. Sprawdź status aplikacji

---

**Ostatnia aktualizacja:** 3 października 2025  
**Status:** ✅ WSZYSTKO DZIAŁA PERFEKCYJNIE
