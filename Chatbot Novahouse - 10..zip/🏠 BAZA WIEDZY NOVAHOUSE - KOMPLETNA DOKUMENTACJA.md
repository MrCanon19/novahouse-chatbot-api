# 🏠 BAZA WIEDZY NOVAHOUSE - KOMPLETNA DOKUMENTACJA

> **Cel:** Dostarczenie chatbotowi pełnej, aktualnej wiedzy o firmie, usługach, cenach i procesach NovaHouse.
> **Ostatnia aktualizacja:** 4 października 2025

---

## 📦 PAKIETY WYKOŃCZENIOWE - SZCZEGÓŁOWE INFORMACJE

### 🍦 **PAKIET WANILIOWY** (Standard)
**Dla kogo:** Inwestorzy pod wynajem, osoby z ograniczonym budżetem, minimaliści

**Zakres prac:**
- Gładzie ścian i sufitów (2 warstwy)
- Malowanie farbą akrylową (biała, 2 warstwy)
- Panele podłogowe laminowane AC3 (klasa 31)
- Płytki ceramiczne w łazience i kuchni (standard)
- Montaż drzwi wewnętrznych (płyta wiórowa)
- Podstawowa armatura sanitarna
- Instalacja elektryczna (gniazdka, włączniki standard)
- Montaż oświetlenia LED (podstawowe)

**Materiały:**
- Panele: Kronopol, Classen (AC3, 7mm)
- Płytki: Cersanit, Paradyż (podstawowa kolekcja)
- Armatura: Ferro, Deante (seria ekonomiczna)
- Drzwi: płyta wiórowa, ościeżnica stalowa
- Farby: Śnieżka, Dekoral (akrylowe)

**Ceny (za m²):**
- 30-50m²: 1,500-1,800 zł/m²
- 51-70m²: 1,400-1,600 zł/m²
- 71-100m²: 1,300-1,500 zł/m²
- 100m²+: 1,200-1,400 zł/m²

**Czas realizacji:**
- 30-50m²: 4-5 tygodni
- 51-70m²: 5-6 tygodni
- 71-100m²: 6-8 tygodni

**Gwarancja:** 2 lata na robociznę, gwarancje producenta na materiały

---

### 🍊 **PAKIET POMARAŃCZOWY** (Premium)
**Dla kogo:** Młode pary, rodziny, osoby ceniące jakość i estetykę

**Zakres prac:**
- Wszystko z Pakietu Waniliowego PLUS:
- Gładzie strukturalne (3 warstwy)
- Malowanie farbą ceramiczną (dowolny kolor, 3 warstwy)
- Panele podłogowe laminowane AC4 (klasa 32)
- Płytki ceramiczne premium w łazience i kuchni
- Drzwi wewnętrzne drewniane (fornir naturalny)
- Armatura sanitarna premium (Grohe, Hansgrohe)
- Instalacja elektryczna rozszerzona (dodatkowe gniazdka, ściemn iacze)
- Oświetlenie LED z możliwością regulacji
- Zabudowa meblowa w łazience (szafka pod umywalkę)
- Parapety wewnętrzne (konglomerat lub drewno)

**Materiały:**
- Panele: Quick-Step, Pergo (AC4, 8mm, wodoodporne)
- Płytki: Tubądzin, Opoczno (kolekcje premium)
- Armatura: Grohe Eurosmart, Hansgrohe Logis
- Drzwi: fornir naturalny, ościeżnica aluminiowa
- Farby: Tikkurila, Dulux (ceramiczne, zmywalne)

**Ceny (za m²):**
- 30-50m²: 2,200-2,600 zł/m²
- 51-70m²: 2,000-2,400 zł/m²
- 71-100m²: 1,900-2,200 zł/m²
- 100m²+: 1,800-2,000 zł/m²

**Czas realizacji:**
- 30-50m²: 5-6 tygodni
- 51-70m²: 6-7 tygodni
- 71-100m²: 7-9 tygodni

**Gwarancja:** 3 lata na robociznę, 5 lat na instalacje, gwarancje producenta

---

### 🌶️ **PAKIET CYNAMONOWY** (Lux)
**Dla kogo:** Wymagający klienci, domy jednorodzinne, apartamenty premium

**Zakres prac:**
- Wszystko z Pakietu Pomarańczowego PLUS:
- Gładzie strukturalne premium (4 warstwy + gruntowanie)
- Malowanie farbą ceramiczną premium (dowolny kolor, efekty specjalne)
- Panele podłogowe drewniane lub wielowarstwowe AC5
- Płytki ceramiczne lux lub kamień naturalny
- Drzwi wewnętrzne drewniane pełne (dąb, jesion)
- Armatura sanitarna lux (Grohe, Hansgrohe serie premium)
- Instalacja elektryczna inteligentna (smart home ready)
- Oświetlenie LED z systemem sterowania
- Zabudowa meblowa premium (szafy, półki, zabudowa TV)
- Parapety wewnętrzne z kamienia naturalnego
- Klimatyzacja (przygotowanie instalacji)
- System audio (przewody, gniazda)

**Materiały:**
- Panele: Barlinek, Tarkett (drewno wielowarstwowe, AC5)
- Płytki: Cerrad, Imola, kamień naturalny (marmur, granit)
- Armatura: Grohe Essence, Hansgrohe Metropol
- Drzwi: drewno pełne (dąb, jesion), ościeżnica ukryta
- Farby: Tikkurila Harmony, Dulux Diamond (premium, antybakteryjne)

**Ceny (za m²):**
- 30-50m²: 3,000-3,600 zł/m²
- 51-70m²: 2,800-3,400 zł/m²
- 71-100m²: 2,600-3,200 zł/m²
- 100m²+: 2,500-3,000 zł/m²

**Czas realizacji:**
- 30-50m²: 6-8 tygodni
- 51-70m²: 7-9 tygodni
- 71-100m²: 8-11 tygodni

**Gwarancja:** 5 lat na robociznę, 10 lat na instalacje, gwarancje producenta

---

### 🌟 **PAKIET SZAFRANOWY** (Ultra Premium)
**Dla kogo:** Klienci VIP, rezydencje, penthouse'y, projekty indywidualne

**Zakres prac:**
- Wszystko z Pakietu Cynamonowego PLUS:
- Projekty indywidualne (architekt wnętrz w cenie)
- Materiały premium na zamówienie
- Meble na wymiar (kuchnia, szafy, zabudowy)
- Inteligentny dom (pełna automatyka)
- Klimatyzacja multi-split
- System audio-video premium
- Oświetlenie sceniczne
- Kamień naturalny ekskluzywny
- Drewno egzotyczne
- Armatura designerska
- Dodatki lux (lustra, akcesoria)

**Materiały:**
- Panele: drewno egzotyczne (tek, wenge, palisander)
- Płytki: kamień naturalny ekskluzywny, mozaiki artystyczne
- Armatura: Grohe Allure, Axor, Villeroy & Boch
- Drzwi: drewno egzotyczne, szkło, designerskie
- Farby: Farrow & Ball, Little Greene (brytyjskie premium)

**Ceny (za m²):**
- Indywidualna wycena, od 4,000 zł/m²
- Projekty na zamówienie

**Czas realizacji:**
- Indywidualny, zazwyczaj 10-16 tygodni

**Gwarancja:** 7 lat na robociznę, 15 lat na instalacje, gwarancje producenta

---

### 🏡 **PAKIET COMFORT** (Dla Seniorów)
**Dla kogo:** Osoby starsze, niepełnosprawne, wymagające dostosowań

**Zakres prac:**
- Wszystko z Pakietu Pomarańczowego PLUS:
- Podłogi antypoślizgowe
- Uchwyty i poręcze w łazience
- Kabina prysznicowa bez progu
- Siedzisko prysznicowe
- Wyższa miska WC
- Szersze drzwi (90cm)
- Oświetlenie z czujnikami ruchu
- Gniazdka na wysokości 60cm (łatwiejszy dostęp)
- Włączniki dotykowe (duże, podświetlane)

**Materiały:**
- Panele: winylowe, antypoślizgowe (R10)
- Płytki: antypoślizgowe (R11), matowe
- Armatura: z długimi dźwigniami, termostatyczna
- Drzwi: lekkie, z samozamykaczem

**Ceny (za m²):**
- 30-50m²: 2,400-2,800 zł/m²
- 51-70m²: 2,200-2,600 zł/m²
- 71-100m²: 2,100-2,400 zł/m²

**Czas realizacji:**
- 30-50m²: 5-6 tygodni
- 51-70m²: 6-7 tygodni

**Gwarancja:** 3 lata na robociznę, 5 lat na instalacje

---

## 💰 FINANSOWANIE I PŁATNOŚCI

### **Harmonogram płatności:**
1. **Zaliczka 30%** - przy podpisaniu umowy
2. **40%** - po zakończeniu prac instalacyjnych
3. **30%** - po odbiorze końcowym

### **Formy płatności:**
- Przelew bankowy
- Płatność kartą
- Płatność ratalna (współpraca z bankami)
- Leasing (dla firm)

### **Finansowanie zewnętrzne:**
- **Kredyt hipoteczny** - możliwość uwzględnienia kosztów wykończenia
- **Kredyt remontowy** - współpraca z PKO BP, mBank, ING
- **Raty 0%** - dla projektów powyżej 100,000 zł (12 miesięcy)

### **Dodatkowe koszty (poza pakietami):**
- Projekt techniczny: 2,000-5,000 zł
- Projekt aranżacji wnętrz: 3,000-10,000 zł
- Nadzór budowlany: 1,500-3,000 zł
- Pozwolenia i dokumenty: 500-2,000 zł
- Transport materiałów: 500-1,500 zł
- Wywóz gruzu: 1,000-3,000 zł

---

## 📋 PROCES REALIZACJI KROK PO KROKU

### **ETAP 1: KONSULTACJA I WYCENA (1-3 dni)**
1. Kontakt z klientem (telefon, email, chatbot)
2. Wizyta w obiekcie lub analiza planów
3. Omówienie potrzeb i oczekiwań
4. Przygotowanie wyceny szczegółowej
5. Prezentacja oferty

### **ETAP 2: UMOWA I PLANOWANIE (3-7 dni)**
1. Podpisanie umowy
2. Wpłata zaliczki (30%)
3. Przygotowanie harmonogramu
4. Zamówienie materiałów
5. Ustalenie daty rozpoczęcia

### **ETAP 3: PRZYGOTOWANIE (1-2 tygodnie)**
1. Zabezpieczenie obiektu
2. Demontaż starych elementów (jeśli dotyczy)
3. Wywóz gruzu
4. Przygotowanie podłoża
5. Kontrola stanu instalacji

### **ETAP 4: PRACE INSTALACYJNE (2-4 tygodnie)**
1. Instalacja elektryczna
2. Instalacja hydrauliczna
3. Instalacja wentylacji/klimatyzacji (jeśli dotyczy)
4. Testy i odbiór instalacji
5. Płatność 40%

### **ETAP 5: PRACE WYKOŃCZENIOWE (2-4 tygodnie)**
1. Gładzie ścian i sufitów
2. Malowanie
3. Układanie podłóg
4. Montaż płytek
5. Montaż drzwi
6. Montaż armatury
7. Montaż oświetlenia

### **ETAP 6: ODBIÓR I FINALIZACJA (1-3 dni)**
1. Sprzątanie końcowe
2. Odbiór techniczny
3. Lista usterek (jeśli są)
4. Usunięcie usterek
5. Odbiór końcowy
6. Płatność końcowa (30%)
7. Przekazanie dokumentów i gwarancji

---

## 🛠️ MATERIAŁY I DOSTAWCY

### **Podłogi:**
- **Laminat:** Kronopol, Quick-Step, Pergo, Classen
- **Winyl:** Tarkett, Wineo, Berry Alloc
- **Drewno:** Barlinek, Tarkett, Jawor-Parkiet
- **Płytki:** Cersanit, Paradyż, Tubądzin, Opoczno

### **Armatura sanitarna:**
- **Ekonomiczna:** Ferro, Deante, Corsan
- **Standard:** Grohe Eurosmart, Hansgrohe Logis
- **Premium:** Grohe Essence, Hansgrohe Metropol, Axor

### **Drzwi:**
- **Ekonomiczne:** Porta, Voster, DRE
- **Premium:** Pol-Skone, Vox, Invado

### **Farby:**
- **Standard:** Śnieżka, Dekoral, Magnat
- **Premium:** Tikkurila, Dulux, Beckers
- **Lux:** Farrow & Ball, Little Greene

### **Płytki:**
- **Standard:** Cersanit, Paradyż (30-60 zł/m²)
- **Premium:** Tubądzin, Opoczno (60-120 zł/m²)
- **Lux:** Cerrad, Imola, kamień naturalny (120-300 zł/m²)

---

## 🏆 GWARANCJE I SERWIS

### **Gwarancje NovaHouse:**
- **Pakiet Waniliowy:** 2 lata na robociznę
- **Pakiet Pomarańczowy:** 3 lata na robociznę, 5 lat na instalacje
- **Pakiet Cynamonowy:** 5 lat na robociznę, 10 lat na instalacje
- **Pakiet Szafranowy:** 7 lat na robociznę, 15 lat na instalacje

### **Gwarancje producentów:**
- Panele: 10-25 lat (zależnie od producenta)
- Armatura: 5-15 lat
- Drzwi: 2-5 lat
- Płytki: dożywotnia (na wady produkcyjne)

### **Serwis posprzedażny:**
- **Bezpłatne przeglądy:** po 6 i 12 miesiącach
- **Usuwanie usterek:** w ciągu 48h od zgłoszenia
- **Hotline:** +48 123 456 789 (pon-pt 8-18)
- **Email:** serwis@novahouse.pl
- **Czas reakcji:** do 24h

---

## 📄 DOKUMENTY I POZWOLENIA

### **Dokumenty wymagane od klienta:**
- Akt własności lub umowa najmu
- Zgoda wspólnoty (jeśli dotyczy)
- Projekt budowlany (dla większych przeróbek)

### **Dokumenty przygotowywane przez NovaHouse:**
- Umowa o wykonanie robót budowlanych
- Harmonogram prac
- Specyfikacja techniczna
- Kosztorys szczegółowy
- Protokoły odbioru
- Karty gwarancyjne

### **Pozwolenia (jeśli wymagane):**
- Zgłoszenie robót budowlanych (do urzędu)
- Zgoda zarządcy/wspólnoty
- Pozwolenie na zajęcie pasa drogowego (kontenery)

**Pomoc w załatwianiu:** NovaHouse pomaga w przygotowaniu dokumentów i uzyskaniu pozwoleń (opcjonalnie, dodatkowa opłata).

---

## 🌍 LOKALIZACJE I ZASIĘG

### **Główne biuro:**
- **Adres:** ul. Przykładowa 123, 80-001 Gdańsk
- **Telefon:** +48 123 456 789
- **Email:** kontakt@novahouse.pl
- **Godziny:** Pon-Pt 8:00-18:00, Sob 9:00-14:00

### **Zasięg działania:**
- **Trójmiasto:** Gdańsk, Gdynia, Sopot (bez dodatkowych kosztów)
- **Pomorskie:** Wejherowo, Reda, Rumia, Tczew (+10% do ceny)
- **Cała Polska:** możliwe, wycena indywidualna

### **Dojazd:**
- Bezpłatna wizyta w Trójmieście
- Poza Trójmiastem: 2 zł/km (w obie strony)

---

## 📞 KONTAKT I UMÓWIENIE SPOTKANIA

### **Sposoby kontaktu:**
1. **Telefon:** +48 123 456 789 (pon-pt 8-18, sob 9-14)
2. **Email:** kontakt@novahouse.pl (odpowiedź do 24h)
3. **Chatbot:** dostępny 24/7 na stronie
4. **Formularz:** www.novahouse.pl/kontakt
5. **Social media:** Facebook, Instagram @novahouse_pl

### **Umówienie spotkania:**
- **Wizyta w biurze:** bezpłatna, umówienie przez telefon/email
- **Wizyta w obiekcie:** bezpłatna w Trójmieście, poza - 2 zł/km
- **Konsultacja online:** bezpłatna, przez Zoom/Teams

### **Czas odpowiedzi:**
- Telefon: natychmiast (w godzinach pracy)
- Email: do 24h
- Chatbot: natychmiast
- Wycena: 1-3 dni robocze

---

## 🎓 FAQ - NAJCZĘSTSZE PYTANIA

### **1. Ile trwa realizacja?**
- Pakiet Waniliowy (50m²): 4-5 tygodni
- Pakiet Pomarańczowy (50m²): 5-6 tygodni
- Pakiet Cynamonowy (50m²): 6-8 tygodni

### **2. Czy mogę mieszkać podczas remontu?**
- Małe mieszkania (do 50m²): niezalecane
- Większe mieszkania (70m²+): możliwe, ale uciążliwe
- Najlepiej: przeprowadzka na czas remontu

### **3. Czy cena jest ostateczna?**
- Tak, jeśli nie ma zmian w projekcie
- Zmiany na życzenie klienta: wycena dodatkowa
- Nieprzewidziane problemy: konsultacja z klientem

### **4. Co jeśli znajdziecie problemy (np. zła instalacja)?**
- Natychmiast informujemy klienta
- Przedstawiamy rozwiązania i koszty
- Klient decyduje o dalszych krokach

### **5. Czy zapewniacie materiały?**
- Tak, wszystkie materiały w cenie pakietu
- Możliwość wyboru z naszej oferty
- Materiały klienta: możliwe, ale bez gwarancji na nie

### **6. Czy można zmienić coś w pakiecie?**
- Tak, pakiety są elastyczne
- Można dodać/usunąć elementy
- Cena dostosowana do zmian

### **7. Jak wygląda gwarancja?**
- Gwarancja na robociznę: 2-7 lat (zależnie od pakietu)
- Gwarancja na materiały: od producenta
- Bezpłatne przeglądy po 6 i 12 miesiącach

### **8. Czy pracujecie w weekendy?**
- Standardowo: pon-pt 7-17
- Weekendy: możliwe za dopłatą (+20%)
- Święta: nie pracujemy

### **9. Co z wywozem gruzu?**
- Wywóz gruzu: 1,000-3,000 zł (zależnie od ilości)
- Kontenery: zapewniamy
- Utylizacja: zgodnie z przepisami

### **10. Czy mogę zobaczyć realizacje?**
- Tak, mamy portfolio na stronie
- Możliwość wizyty w realizowanych projektach (za zgodą klienta)
- Referencje od klientów

---

## 🏅 REFERENCJE I PORTFOLIO

### **Statystyki:**
- **Zrealizowane projekty:** 500+ (od 2018)
- **Zadowoleni klienci:** 98%
- **Średnia ocena:** 4.9/5
- **Polecenia:** 85% klientów poleca nas dalej

### **Przykładowe realizacje:**
1. **Mieszkanie 45m² - Gdańsk Wrzeszcz** (Pakiet Pomarańczowy)
   - Czas: 5 tygodni
   - Koszt: 108,000 zł
   - Ocena: 5/5

2. **Mieszkanie 80m² - Gdynia Śródmieście** (Pakiet Cynamonowy)
   - Czas: 8 tygodni
   - Koszt: 224,000 zł
   - Ocena: 5/5

3. **Dom 150m² - Sopot** (Pakiet Szafranowy)
   - Czas: 14 tygodni
   - Koszt: 630,000 zł
   - Ocena: 5/5

### **Opinie klientów:**
> "Profesjonalizm na najwyższym poziomie. Wszystko zgodnie z harmonogramem!" - Anna K., Gdańsk

> "Rewelacyjna jakość, super kontakt, polecam!" - Marek T., Gdynia

> "Najlepsza decyzja! Mieszkanie wygląda jak z katalogu." - Ewa i Tomasz N., Sopot

---

## 🎯 TYPY KLIENTÓW I REKOMENDACJE

### **1. Młoda para (pierwsze mieszkanie)**
- **Budżet:** 80,000-150,000 zł
- **Metraż:** 40-70m²
- **Rekomendacja:** Pakiet Pomarańczowy
- **Priorytet:** Jakość, estetyka, funkcjonalność

### **2. Rodzina z dziećmi**
- **Budżet:** 120,000-250,000 zł
- **Metraż:** 60-100m²
- **Rekomendacja:** Pakiet Pomarańczowy lub Cynamonowy
- **Priorytet:** Trwałość, bezpieczeństwo, przestrzeń

### **3. Inwestor (wynajem)**
- **Budżet:** 60,000-120,000 zł
- **Metraż:** 30-60m²
- **Rekomendacja:** Pakiet Waniliowy
- **Priorytet:** Koszt, szybkość, ROI

### **4. Senior**
- **Budżet:** 100,000-180,000 zł
- **Metraż:** 40-70m²
- **Rekomendacja:** Pakiet Comfort
- **Priorytet:** Bezpieczeństwo, wygoda, dostępność

### **5. Singiel (kawalerka)**
- **Budżet:** 50,000-100,000 zł
- **Metraż:** 25-40m²
- **Rekomendacja:** Pakiet Waniliowy lub Pomarańczowy
- **Priorytet:** Funkcjonalność, nowoczesność

### **6. Klient VIP (luksusowy apartament)**
- **Budżet:** 300,000+ zł
- **Metraż:** 80m²+
- **Rekomendacja:** Pakiet Szafranowy
- **Priorytet:** Ekskluzywność, indywidualny design

### **7. Przedsiębiorca (biuro)**
- **Budżet:** 100,000-300,000 zł
- **Metraż:** 50-150m²
- **Rekomendacja:** Pakiet Cynamonowy
- **Priorytet:** Reprezentacyjność, funkcjonalność

### **8. Deweloper (inwestycja masowa)**
- **Budżet:** negocjacje
- **Metraż:** wiele lokali
- **Rekomendacja:** Pakiet Waniliowy (rabaty hurtowe)
- **Priorytet:** Koszt, terminowość, skala

---

## 🔧 DODATKOWE USŁUGI

### **Projektowanie:**
- Projekt aranżacji wnętrz: 3,000-10,000 zł
- Projekt techniczny: 2,000-5,000 zł
- Wizualizacje 3D: 1,000-3,000 zł

### **Nadzór:**
- Nadzór budowlany: 1,500-3,000 zł
- Koordynacja dostaw: 500-1,500 zł

### **Dodatkowe prace:**
- Wyburzenia: 50-150 zł/m²
- Przeróbki instalacji: wycena indywidualna
- Meble na wymiar: wycena indywidualna
- Inteligentny dom: od 10,000 zł

---

## 📊 PORÓWNANIE PAKIETÓW

| Element | Waniliowy | Pomarańczowy | Cynamonowy | Szafranowy |
|---------|-----------|--------------|------------|------------|
| **Cena/m²** | 1,200-1,800 zł | 1,800-2,600 zł | 2,500-3,600 zł | od 4,000 zł |
| **Panele** | AC3 (7mm) | AC4 (8mm) | AC5 drewno | Egzotyczne |
| **Płytki** | Standard | Premium | Lux/kamień | Ekskluzywne |
| **Armatura** | Ekonomiczna | Grohe/Hansgrohe | Premium | Designerska |
| **Drzwi** | Płyta wiórowa | Fornir | Drewno pełne | Egzotyczne |
| **Gwarancja** | 2 lata | 3 lata | 5 lat | 7 lat |
| **Czas** | 4-5 tyg | 5-6 tyg | 6-8 tyg | 10-16 tyg |

---

## ⚠️ WAŻNE INFORMACJE

### **Sezonowość:**
- **Najlepszy czas:** kwiecień-październik (suche, ciepłe)
- **Zima:** możliwe, ale +1-2 tygodnie (schnięcie)
- **Wakacje:** dłuższe terminy (urlopy ekip)

### **Przygotowanie klienta:**
- Opróżnienie mieszkania (meble, rzeczy osobiste)
- Zabezpieczenie cennych przedmiotów
- Zapewnienie dostępu do wody i prądu
- Informacja sąsiadów o remoncie

### **Dodatkowe koszty (możliwe):**
- Nieprzewidziane problemy (zła instalacja): wycena indywidualna
- Zmiany w projekcie na życzenie klienta: wycena indywidualna
- Materiały premium poza pakietem: wycena indywidualna

---

**KONIEC BAZY WIEDZY**

> **Uwaga dla chatbota:** Używaj tej wiedzy do udzielania precyzyjnych, konkretnych odpowiedzi. Zawsze podawaj ceny, czasy realizacji i szczegóły. Bądź profesjonalny, ale przyjazny. Nie wymyślaj informacji - jeśli czegoś nie ma w bazie wiedzy, powiedz że sprawdzisz i skontaktujesz się z klientem.
