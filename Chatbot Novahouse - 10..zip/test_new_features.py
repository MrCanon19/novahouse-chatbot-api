"""
Test script for new features: Conversation Memory and Intent-Driven Actions
"""

import sys
import os

# Add src to path
sys.path.insert(0, '/home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api')

def test_imports():
    """Test if all new modules can be imported"""
    print("=" * 60)
    print("TEST 1: Testing imports")
    print("=" * 60)
    
    try:
        from src.conversation_memory import conversation_memory
        print("✓ conversation_memory imported successfully")
    except Exception as e:
        print(f"✗ Failed to import conversation_memory: {e}")
        return False
    
    try:
        from src.intent_actions import intent_action_handler
        print("✓ intent_actions imported successfully")
    except Exception as e:
        print(f"✗ Failed to import intent_actions: {e}")
        return False
    
    try:
        from src.routes.chatbot import chatbot_bp
        print("✓ chatbot routes imported successfully")
    except Exception as e:
        print(f"✗ Failed to import chatbot routes: {e}")
        return False
    
    print("\n✅ All imports successful!\n")
    return True


def test_conversation_memory():
    """Test conversation memory functionality"""
    print("=" * 60)
    print("TEST 2: Testing Conversation Memory")
    print("=" * 60)
    
    try:
        from src.conversation_memory import ConversationMemory
        
        # Create instance
        memory = ConversationMemory(max_messages=6)
        print("✓ ConversationMemory instance created")
        
        # Test build_gpt_messages
        test_session = "test_session_123"
        system_prompt = "You are a helpful assistant"
        current_message = "Hello, how are you?"
        
        messages = memory.build_gpt_messages(test_session, system_prompt, current_message)
        
        # Should have at least system prompt and current message
        if len(messages) >= 2:
            print(f"✓ build_gpt_messages works (returned {len(messages)} messages)")
        else:
            print(f"✗ build_gpt_messages returned too few messages: {len(messages)}")
            return False
        
        # Test get_context_summary
        summary = memory.get_context_summary(test_session)
        print(f"✓ get_context_summary works (length: {len(summary)} chars)")
        
        print("\n✅ Conversation Memory tests passed!\n")
        return True
        
    except Exception as e:
        print(f"✗ Conversation Memory test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_intent_actions():
    """Test intent-driven actions functionality"""
    print("=" * 60)
    print("TEST 3: Testing Intent-Driven Actions")
    print("=" * 60)
    
    try:
        from src.intent_actions import IntentActionHandler
        
        # Create instance
        handler = IntentActionHandler()
        print("✓ IntentActionHandler instance created")
        
        # Test 1: Check action with missing entities
        intent = "umowienie_spotkania"
        entities = {"email": "test@example.com"}  # Missing phone
        session_id = "test_session_456"
        
        result = handler.check_and_execute(intent, entities, session_id)
        
        if result and result['status'] == 'pending':
            print(f"✓ Correctly detected missing entities: {result['missing_entities']}")
        else:
            print(f"✗ Failed to detect missing entities: {result}")
            return False
        
        # Test 2: Check action with all required entities
        entities_complete = {
            "numer_telefonu": "123456789",
            "email": "test@example.com"
        }
        
        # Note: This will try to create a lead, which might fail without DB
        # but we're just testing the logic flow
        result2 = handler.check_and_execute(intent, entities_complete, session_id)
        
        if result2:
            print(f"✓ Action handler returned result with status: {result2['status']}")
        else:
            print("✓ Action handler processed request (no result for non-action intent)")
        
        # Test 3: Check non-action intent
        result3 = handler.check_and_execute("powitanie", {}, session_id)
        
        if result3 is None:
            print("✓ Correctly returned None for non-action intent")
        else:
            print(f"✗ Should return None for non-action intent, got: {result3}")
        
        # Test 4: Test _build_missing_entities_message
        message = handler._build_missing_entities_message("umowienie_spotkania", ["numer_telefonu"])
        if "numer telefonu" in message.lower():
            print(f"✓ Missing entities message built correctly: {message[:50]}...")
        else:
            print(f"✗ Missing entities message incorrect: {message}")
            return False
        
        print("\n✅ Intent-Driven Actions tests passed!\n")
        return True
        
    except Exception as e:
        print(f"✗ Intent-Driven Actions test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_integration():
    """Test integration of new features with chatbot"""
    print("=" * 60)
    print("TEST 4: Testing Integration")
    print("=" * 60)
    
    try:
        # Check if the chatbot imports the new modules
        from src.routes import chatbot
        
        # Check if conversation_memory is imported
        if hasattr(chatbot, 'conversation_memory'):
            print("✓ conversation_memory is available in chatbot module")
        else:
            print("⚠ conversation_memory not found in chatbot module (might be imported differently)")
        
        # Check if intent_action_handler is imported
        if hasattr(chatbot, 'intent_action_handler'):
            print("✓ intent_action_handler is available in chatbot module")
        else:
            print("⚠ intent_action_handler not found in chatbot module (might be imported differently)")
        
        # Try to get the chatbot class
        if hasattr(chatbot, 'NovaHouseProfessionalChatbot'):
            print("✓ NovaHouseProfessionalChatbot class found")
            
            # Check if generate_professional_response exists
            bot_class = chatbot.NovaHouseProfessionalChatbot
            if hasattr(bot_class, 'generate_professional_response'):
                print("✓ generate_professional_response method exists")
            else:
                print("✗ generate_professional_response method not found")
                return False
        else:
            print("✗ NovaHouseProfessionalChatbot class not found")
            return False
        
        print("\n✅ Integration tests passed!\n")
        return True
        
    except Exception as e:
        print(f"✗ Integration test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_action_definitions():
    """Test that all action intents are properly defined"""
    print("=" * 60)
    print("TEST 5: Testing Action Definitions")
    print("=" * 60)
    
    try:
        from src.intent_actions import IntentActionHandler
        
        handler = IntentActionHandler()
        
        # Check action intents
        expected_intents = [
            "umowienie_spotkania",
            "wycena_konkretna",
            "zapytanie_o_pakiety",
            "kontakt_zwrotny"
        ]
        
        for intent in expected_intents:
            if intent in handler.action_intents:
                config = handler.action_intents[intent]
                print(f"✓ {intent}: {config['description']}")
                print(f"  - Required: {', '.join(config['required'])}")
                print(f"  - Priority: {config['priority']}")
            else:
                print(f"✗ {intent} not found in action_intents")
                return False
        
        print(f"\n✓ Total action intents defined: {len(handler.action_intents)}")
        
        print("\n✅ Action definitions tests passed!\n")
        return True
        
    except Exception as e:
        print(f"✗ Action definitions test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Run all tests"""
    print("\n" + "=" * 60)
    print("NOVAHOUSE CHATBOT - NEW FEATURES TEST SUITE")
    print("=" * 60 + "\n")
    
    results = []
    
    # Run tests
    results.append(("Imports", test_imports()))
    results.append(("Conversation Memory", test_conversation_memory()))
    results.append(("Intent-Driven Actions", test_intent_actions()))
    results.append(("Integration", test_integration()))
    results.append(("Action Definitions", test_action_definitions()))
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{test_name:.<40} {status}")
    
    print("\n" + "=" * 60)
    print(f"TOTAL: {passed}/{total} tests passed")
    print("=" * 60 + "\n")
    
    if passed == total:
        print("🎉 All tests passed! Ready for deployment!")
        return 0
    else:
        print("⚠️  Some tests failed. Please fix issues before deployment.")
        return 1


if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

