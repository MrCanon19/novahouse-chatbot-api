# 📦 INSTRUKCJA WDROŻENIA - NOVAHOUSE CHATBOT

## 🎯 CEL
Wdrożenie wszystkich ulepszeń na Google Cloud Platform (GCP)

---

## ✅ PRZED WDROŻENIEM

### Sprawdź co jest gotowe:
```bash
# Sprawdź czy wszystkie pliki są na miejscu
ls -la /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api/src/

# Powinny być:
# - routes/chatbot.py (zmodyfikowany)
# - models/chatbot.py (zmodyfikowany)
# - intelligent_expert.py (zmodyfikowany)
# - validation.py (NOWY)
```

### Sprawdź bazę danych:
```bash
# Sprawdź czy migracje zostały wykonane
python3.11 /home/ubuntu/check_database.py

# Powinno pokazać:
# - Rozmowy: 69+
# - Intencje: 29 (było 24)
# - Encje: 20 (było 15)
# - Leady: 2+
# - KnowledgeBase: 1 rekord
# - SessionContext: 0+ rekordów
```

---

## 🚀 WDROŻENIE KROK PO KROKU

### KROK 1: Zaloguj się do GCP

```bash
# Zaloguj się
gcloud auth login

# Wybierz projekt
gcloud config set project glass-core-467907-e9

# Sprawdź czy jesteś zalogowany
gcloud auth list
```

### KROK 2: Przejdź do katalogu projektu

```bash
cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api
```

### KROK 3: Wdróż aplikację

```bash
# Wdrożenie (trwa ~5-10 minut)
gcloud app deploy app.yaml --quiet

# Poczekaj na komunikat:
# "Deployed service [default] to [https://glass-core-467907-e9.ey.r.appspot.com]"
```

### KROK 4: Sprawdź czy działa

```bash
# Sprawdź health
curl https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/health

# Powinno zwrócić:
# {"status": "healthy", "chatbot_loaded": true, "gpt_configured": true}
```

---

## 🧪 TESTY PO WDROŻENIU

### TEST 1: Pamięć kontekstu

```bash
# Uruchom test
python3.11 /home/ubuntu/test_comprehensive.py

# Sprawdź czy:
# ✅ PASS: Pamięć kontekstu
```

### TEST 2: Nowe intencje

```bash
# Test ręczny
curl -X POST https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Czy macie gwarancję?", "session_id": "test123"}'

# Sprawdź czy odpowiedź zawiera informacje o gwarancji
```

### TEST 3: Walidacja

```bash
# Test ręczny
curl -X POST https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/chat \
  -H "Content-Type: application/json" \
  -d '{"message": "Chcę spotkanie, telefon: 123-456-789", "session_id": "test456"}'

# Sprawdź czy lead został utworzony z poprawnym numerem
```

---

## 📊 MONITORING PO WDROŻENIU

### Sprawdź logi:

```bash
# Ostatnie 50 wpisów
gcloud app logs tail -s default --project glass-core-467907-e9

# Szukaj błędów
gcloud app logs read --limit=100 --project glass-core-467907-e9 | grep ERROR
```

### Sprawdź metryki:

1. Otwórz panel admin: https://glass-core-467907-e9.ey.r.appspot.com/static/admin.html
2. Sprawdź zakładki:
   - Dashboard (statystyki)
   - Rozmowy (historia)
   - Leady (nowe leady)
   - Intencje (29 intencji)
   - Encje (20 encji)
   - Baza wiedzy (581 linii)

---

## ⚠️ W RAZIE PROBLEMÓW

### Problem: Błąd wdrożenia

```bash
# Sprawdź szczegóły błędu
gcloud app logs read --limit=50 --project glass-core-467907-e9

# Rollback do poprzedniej wersji
gcloud app versions list --project glass-core-467907-e9
gcloud app versions migrate [PREVIOUS_VERSION] --project glass-core-467907-e9
```

### Problem: Błąd w aplikacji

```bash
# Sprawdź logi na żywo
gcloud app logs tail -s default --project glass-core-467907-e9

# Sprawdź health endpoint
curl https://glass-core-467907-e9.ey.r.appspot.com/api/chatbot/health
```

### Problem: Baza danych

```bash
# Sprawdź połączenie z bazą
python3.11 /home/ubuntu/check_database.py

# Jeśli problem, sprawdź app.yaml:
cat app.yaml | grep DB_
```

---

## 📋 CHECKLIST WDROŻENIA

- [ ] Zalogowano do GCP
- [ ] Wybrano projekt glass-core-467907-e9
- [ ] Wdrożono aplikację (gcloud app deploy)
- [ ] Sprawdzono health endpoint
- [ ] Przetestowano pamięć kontekstu
- [ ] Przetestowano nowe intencje
- [ ] Przetestowano walidację
- [ ] Sprawdzono panel admin
- [ ] Sprawdzono logi (brak błędów)
- [ ] Monitorowano przez 1h

---

## 🎉 SUKCES!

Jeśli wszystkie testy przeszły, system jest gotowy do użycia produkcyjnego!

**Następne kroki:**
1. Monitoruj metryki przez 24h
2. Zbieraj feedback od użytkowników
3. Zaplanuj implementację MUST HAVE ulepszeń

---

**Pytania?** Sprawdź RAPORT_KONCOWY_WSZYSTKO.md
