# ✅ Checklist Wdrożenia NovaHouse Chatbot

## Przed Wdrożeniem

- [ ] Sprawdź, czy jesteś zalogowany do GCP
  ```bash
  gcloud auth list
  ```

- [ ] Ustaw właściwy projekt
  ```bash
  gcloud config set project glass-core-467907-e9
  ```

- [ ] Sprawdź konfigurację app.yaml
  ```bash
  cat app.yaml | grep -A 5 "env_variables"
  ```

- [ ] Upewnij się, że baza danych jest dostępna
  ```bash
  gcloud sql instances describe novahouse-chatbot-db
  ```

## Wdrożenie

- [ ] Przejdź do katalogu projektu
  ```bash
  cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api
  ```

- [ ] Wdróż aplikację
  ```bash
  gcloud app deploy app.yaml --quiet
  ```

- [ ] Poczekaj na zakończenie wdrożenia (2-5 minut)

## Po Wdrożeniu

- [ ] Sprawdź status aplikacji
  ```bash
  gcloud app browse
  ```

- [ ] Testuj endpoint health
  ```bash
  curl https://glass-core-467907-e9.appspot.com/api/health
  ```

- [ ] Testuj nowy endpoint stats
  ```bash
  curl https://glass-core-467907-e9.appspot.com/api/analytics/stats
  ```

- [ ] Otwórz panel administracyjny
  ```
  https://glass-core-467907-e9.appspot.com/static/admin.html
  ```

- [ ] Sprawdź zakładki w panelu admin:
  - [ ] Dashboard - statystyki się ładują
  - [ ] Rozmowy - historia konwersacji widoczna
  - [ ] Intencje - lista intencji widoczna
  - [ ] Encje - lista encji widoczna

- [ ] Testuj chatbot
  ```
  https://glass-core-467907-e9.appspot.com/static/chatbot.html
  ```

- [ ] Wyślij testową wiadomość z danymi kontaktowymi

- [ ] Sprawdź w Monday.com, czy lead został utworzony
  - Board: "Chat"
  - Grupa: "Leady z chatbota"

## Monitoring

- [ ] Sprawdź logi aplikacji
  ```bash
  gcloud app logs tail -s default
  ```

- [ ] Monitoruj błędy przez pierwsze 15 minut

## W Razie Problemów

### Problem: Aplikacja nie startuje
```bash
# Sprawdź logi
gcloud app logs read --limit=50

# Sprawdź status Cloud SQL
gcloud sql instances describe novahouse-chatbot-db
```

### Problem: Błąd połączenia z bazą danych
```bash
# Sprawdź IP Cloud SQL
gcloud sql instances describe novahouse-chatbot-db | grep ipAddress

# Sprawdź, czy IP w app.yaml jest poprawne
grep "DATABASE_URL" app.yaml
```

### Problem: Monday.com nie tworzy leadów
```bash
# Sprawdź logi aplikacji
gcloud app logs tail -s default | grep "Monday"

# Sprawdź, czy API key jest ustawiony
grep "MONDAY_API_KEY" app.yaml
```

### Problem: Panel admin nie ładuje danych
```bash
# Otwórz konsolę przeglądarki (F12)
# Sprawdź zakładkę Network
# Poszukaj błędów 404 lub 500
```

## Rollback (Cofnięcie Wdrożenia)

Jeśli coś pójdzie nie tak:

```bash
# Lista wersji aplikacji
gcloud app versions list

# Przełącz na poprzednią wersję
gcloud app versions migrate [PREVIOUS_VERSION_ID]

# Usuń problematyczną wersję
gcloud app versions delete [CURRENT_VERSION_ID]
```

## Kontakt w Razie Pytań

- Dokumentacja: `/home/ubuntu/POPRAWKI_WDROZENIE_FINAL.md`
- Logi: `gcloud app logs tail -s default`
- Status: `gcloud app browse`

---

**Data:** 1 października 2025  
**Wersja:** 1.0  
**Status:** Gotowy do użycia
