"""
Intent-Driven Actions Module - Automatic action execution when bot has all required data
Handles actions like scheduling meetings, generating quotes, creating leads
"""

import json
from datetime import datetime


def safe_log(message):
    """Safely log a message, handling missing app context"""
    try:
        from flask import current_app
        current_app.logger.info(message)
    except (RuntimeError, ImportError):
        pass


def safe_log_error(message):
    """Safely log an error, handling missing app context"""
    try:
        from flask import current_app
        current_app.logger.error(message)
    except (RuntimeError, ImportError):
        pass


class IntentActionHandler:
    """Handles automatic execution of actions based on intents and collected entities"""
    
    def __init__(self):
        """Initialize action handler with action definitions"""
        
        # Define actions for each intent with required entities
        self.action_intents = {
            "umowienie_spotkania": {
                "required": ["numer_telefonu"],
                "optional": ["email", "imie_klienta"],
                "action": self.create_meeting_request,
                "priority": "HIGH",
                "description": "Umówienie spotkania z klientem"
            },
            "wycena_konkretna": {
                "required": ["metraz_mieszkania", "pakiet_wykonczeniowy"],
                "optional": ["budżet_klienta", "lokalizacja"],
                "action": self.generate_quote,
                "priority": "MEDIUM",
                "description": "Generowanie konkretnej wyceny"
            },
            "zapytanie_o_pakiety": {
                "required": ["metraz_mieszkania", "budżet_klienta"],
                "optional": ["lokalizacja", "typ_nieruchomosci"],
                "action": self.recommend_package,
                "priority": "MEDIUM",
                "description": "Rekomendacja pakietu"
            },
            "kontakt_zwrotny": {
                "required": ["numer_telefonu"],
                "optional": ["email", "imie_klienta"],
                "action": self.create_callback_request,
                "priority": "HIGH",
                "description": "Prośba o kontakt zwrotny"
            }
        }
    
    def check_and_execute(self, intent, entities, session_id):
        """
        Check if action can be executed and execute it
        
        Args:
            intent: Detected intent
            entities: Collected entities
            session_id: Session identifier
            
        Returns:
            Dictionary with action result or None if action not executed
        """
        try:
            # Check if this intent has an associated action
            if intent not in self.action_intents:
                return None
            
            action_config = self.action_intents[intent]
            
            # Check if all required entities are present
            required = action_config["required"]
            missing = [r for r in required if not entities.get(r)]
            
            if missing:
                # Not ready to execute - return missing entities
                return {
                    "status": "pending",
                    "intent": intent,
                    "missing_entities": missing,
                    "message": self._build_missing_entities_message(intent, missing)
                }
            
            # All required entities present - execute action!
            try:
                from flask import current_app
                current_app.logger.info(f"Executing action for intent: {intent}")
            except (RuntimeError, ImportError):
                pass
            
            action_result = action_config["action"](entities, session_id)
            
            return {
                "status": "executed",
                "intent": intent,
                "priority": action_config["priority"],
                "description": action_config["description"],
                "result": action_result
            }
            
        except Exception as e:
            try:
                from flask import current_app
                current_app.logger.error(f"Error executing action for intent {intent}: {e}")
            except (RuntimeError, ImportError):
                pass
            return {
                "status": "error",
                "intent": intent,
                "error": str(e)
            }
    
    def _build_missing_entities_message(self, intent, missing):
        """
        Build a message asking for missing entities
        
        Args:
            intent: Intent name
            missing: List of missing entity names
            
        Returns:
            String with message asking for missing information
        """
        entity_labels = {
            'numer_telefonu': 'numer telefonu',
            'email': 'adres email',
            'imie_klienta': 'imię',
            'metraz_mieszkania': 'metraż mieszkania',
            'budżet_klienta': 'budżet',
            'pakiet_wykonczeniowy': 'wybrany pakiet',
            'lokalizacja': 'lokalizacja',
            'typ_nieruchomosci': 'typ nieruchomości'
        }
        
        missing_labels = [entity_labels.get(m, m) for m in missing]
        
        if intent == "umowienie_spotkania":
            return f"Aby umówić spotkanie, potrzebuję jeszcze: {', '.join(missing_labels)}."
        elif intent == "wycena_konkretna":
            return f"Aby przygotować dokładną wycenę, potrzebuję: {', '.join(missing_labels)}."
        elif intent == "zapytanie_o_pakiety":
            return f"Aby polecić odpowiedni pakiet, potrzebuję: {', '.join(missing_labels)}."
        else:
            return f"Potrzebuję jeszcze: {', '.join(missing_labels)}."
    
    def create_meeting_request(self, entities, session_id):
        """
        Create a meeting request and lead in Monday.com
        
        Args:
            entities: Dictionary of entities
            session_id: Session identifier
            
        Returns:
            Dictionary with result
        """
        try:
            from src.monday_lead_creator import create_lead_from_chat
            from src.validation import validate_phone, validate_email
            
            # Validate phone
            phone = entities.get('numer_telefonu', '')
            is_valid_phone, cleaned_phone = validate_phone(phone)
            
            if not is_valid_phone:
                return {
                    "success": False,
                    "message": "Nieprawidłowy numer telefonu. Podaj poprawny numer w formacie polskim."
                }
            
            # Validate email if provided
            email = entities.get('email', '')
            if email:
                is_valid_email, cleaned_email = validate_email(email)
                if not is_valid_email:
                    email = ''
            else:
                cleaned_email = ''
            
            # Prepare lead data
            lead_data = {
                'session_id': session_id,
                'phone': cleaned_phone,
                'email': cleaned_email,
                'name': entities.get('imie_klienta', 'Klient'),
                'interested_package': entities.get('pakiet_wykonczeniowy', entities.get('typ_pakietu', '')),
                'property_size': entities.get('metraz_mieszkania', ''),
                'location': entities.get('lokalizacja', entities.get('lokalizacja_miasta', '')),
                'budget': entities.get('budżet_klienta', entities.get('budzet_klienta', '')),
                'action_type': 'meeting_request',
                'priority': 'HIGH'
            }
            
            # Create lead in database and Monday.com
            result = create_lead_from_chat(lead_data)
            
            if result.get('success'):
                return {
                    "success": True,
                    "action": "meeting_scheduled",
                    "message": "✅ Spotkanie zostało zarezerwowane! Skontaktujemy się z Tobą w ciągu 24 godzin, aby potwierdzić termin.",
                    "lead_id": result.get('lead_id'),
                    "monday_item_id": result.get('monday_item_id')
                }
            else:
                return {
                    "success": False,
                    "message": "Wystąpił problem z zarezerwowaniem spotkania. Spróbuj ponownie lub zadzwoń do nas."
                }
                
        except Exception as e:
            current_app.logger.error(f"Error creating meeting request: {e}")
            return {
                "success": False,
                "message": "Wystąpił błąd techniczny. Prosimy o kontakt telefoniczny."
            }
    
    def generate_quote(self, entities, session_id):
        """
        Generate a detailed quote based on entities
        
        Args:
            entities: Dictionary of entities
            session_id: Session identifier
            
        Returns:
            Dictionary with quote details
        """
        try:
            from src.ai_recommendations import ai_engine
            
            # Get package details
            package = entities.get('pakiet_wykonczeniowy', entities.get('typ_pakietu', '')).lower()
            metraz = entities.get('metraz_mieszkania', '')
            
            # Extract numeric value from metraz
            import re
            metraz_match = re.search(r'(\d+)', str(metraz))
            if not metraz_match:
                return {
                    "success": False,
                    "message": "Nie mogę obliczyć wyceny bez podania metrażu."
                }
            
            metraz_num = int(metraz_match.group(1))
            
            # Package price ranges (zł/m²)
            package_prices = {
                'waniliowy': (1200, 1500),
                'pomarańczowy': (1800, 2200),
                'pomaranczowy': (1800, 2200),
                'cynamonowy': (2500, 3000),
                'szafranowy': (3500, 4500)
            }
            
            if package not in package_prices:
                # Use AI recommendations to suggest package
                recommendations = ai_engine.recommend(entities, {})
                if recommendations:
                    package = recommendations[0]['package']
                else:
                    package = 'pomarańczowy'  # Default
            
            price_range = package_prices.get(package, (1800, 2200))
            
            # Calculate costs
            min_cost = metraz_num * price_range[0]
            max_cost = metraz_num * price_range[1]
            avg_cost = (min_cost + max_cost) / 2
            
            # Estimate timeline
            if metraz_num < 50:
                timeline = "4-6 tygodni"
            elif metraz_num < 80:
                timeline = "6-8 tygodni"
            else:
                timeline = "8-12 tygodni"
            
            # Build quote message
            quote_message = f"""
📊 **WYCENA WSTĘPNA**

**Pakiet:** {package.title()}
**Metraż:** {metraz_num} m²
**Lokalizacja:** {entities.get('lokalizacja', entities.get('lokalizacja_miasta', 'do ustalenia'))}

💰 **Szacunkowy koszt:**
- Minimalny: {min_cost:,.0f} zł
- Maksymalny: {max_cost:,.0f} zł
- Średnio: {avg_cost:,.0f} zł

⏱️ **Czas realizacji:** {timeline}

📋 **Co zawiera pakiet {package.title()}:**
"""
            
            # Add package details
            package_details = {
                'waniliowy': "• Podstawowe materiały dobrej jakości\n• Standardowe wykończenie\n• Gwarancja 2 lata",
                'pomarańczowy': "• Materiały średniej-wyższej klasy\n• Staranne wykończenie\n• Gwarancja 3 lata\n• Najczęściej wybierany!",
                'pomaranczowy': "• Materiały średniej-wyższej klasy\n• Staranne wykończenie\n• Gwarancja 3 lata\n• Najczęściej wybierany!",
                'cynamonowy': "• Materiały premium\n• Wykończenie wysokiej jakości\n• Gwarancja 5 lat\n• Indywidualne rozwiązania",
                'szafranowy': "• Najwyższa jakość materiałów\n• Luksusowe wykończenie\n• Gwarancja 7 lat\n• Pełna personalizacja"
            }
            
            quote_message += package_details.get(package, "• Szczegóły do uzgodnienia")
            
            quote_message += "\n\n✨ **Następny krok:** Umów się na bezpłatną konsultację, aby otrzymać dokładną wycenę dostosowaną do Twoich potrzeb!"
            
            # Save quote to database
            self._save_quote_to_db(session_id, entities, {
                'package': package,
                'metraz': metraz_num,
                'min_cost': min_cost,
                'max_cost': max_cost,
                'timeline': timeline
            })
            
            return {
                "success": True,
                "action": "quote_generated",
                "message": quote_message,
                "quote_data": {
                    "package": package,
                    "metraz": metraz_num,
                    "cost_range": [min_cost, max_cost],
                    "timeline": timeline
                }
            }
            
        except Exception as e:
            current_app.logger.error(f"Error generating quote: {e}")
            return {
                "success": False,
                "message": "Nie mogę wygenerować wyceny. Skontaktuj się z nami bezpośrednio."
            }
    
    def recommend_package(self, entities, session_id):
        """
        Recommend best package based on entities
        
        Args:
            entities: Dictionary of entities
            session_id: Session identifier
            
        Returns:
            Dictionary with recommendations
        """
        try:
            from src.ai_recommendations import ai_engine
            
            # Get AI recommendations
            recommendations = ai_engine.recommend(entities, {})
            
            if not recommendations:
                return {
                    "success": False,
                    "message": "Nie mogę polecić pakietu. Potrzebuję więcej informacji."
                }
            
            # Build recommendation message
            top_reco = recommendations[0]
            
            message = f"""
🎯 **REKOMENDACJA PAKIETU**

Na podstawie Twoich potrzeb polecam: **Pakiet {top_reco['package'].title()}**

💡 **Dlaczego?**
"""
            
            for reason in top_reco['reasons'][:3]:
                message += f"\n✓ {reason}"
            
            message += f"""

💰 **Cena:** {top_reco['price_range'][0]}-{top_reco['price_range'][1]} zł/m²
📊 **Pewność rekomendacji:** {top_reco['confidence']}
"""
            
            # Add alternative if available
            if len(recommendations) > 1:
                alt_reco = recommendations[1]
                message += f"\n\n📌 **Alternatywa:** Pakiet {alt_reco['package'].title()} ({alt_reco['price_range'][0]}-{alt_reco['price_range'][1]} zł/m²)"
            
            message += "\n\n💬 Chcesz dowiedzieć się więcej o tym pakiecie?"
            
            return {
                "success": True,
                "action": "package_recommended",
                "message": message,
                "recommendations": recommendations[:2]
            }
            
        except Exception as e:
            current_app.logger.error(f"Error recommending package: {e}")
            return {
                "success": False,
                "message": "Nie mogę polecić pakietu w tym momencie."
            }
    
    def create_callback_request(self, entities, session_id):
        """
        Create a callback request
        
        Args:
            entities: Dictionary of entities
            session_id: Session identifier
            
        Returns:
            Dictionary with result
        """
        try:
            from src.monday_lead_creator import create_lead_from_chat
            from src.validation import validate_phone
            
            # Validate phone
            phone = entities.get('numer_telefonu', '')
            is_valid_phone, cleaned_phone = validate_phone(phone)
            
            if not is_valid_phone:
                return {
                    "success": False,
                    "message": "Nieprawidłowy numer telefonu."
                }
            
            # Create callback lead
            lead_data = {
                'session_id': session_id,
                'phone': cleaned_phone,
                'email': entities.get('email', ''),
                'name': entities.get('imie_klienta', 'Klient'),
                'action_type': 'callback_request',
                'priority': 'HIGH'
            }
            
            result = create_lead_from_chat(lead_data)
            
            if result.get('success'):
                return {
                    "success": True,
                    "action": "callback_scheduled",
                    "message": "✅ Zarejestrowano prośbę o kontakt! Oddzwonimy do Ciebie w ciągu 2 godzin (w godzinach pracy).",
                    "lead_id": result.get('lead_id')
                }
            else:
                return {
                    "success": False,
                    "message": "Wystąpił problem. Spróbuj ponownie."
                }
                
        except Exception as e:
            current_app.logger.error(f"Error creating callback request: {e}")
            return {
                "success": False,
                "message": "Wystąpił błąd techniczny."
            }
    
    def _save_quote_to_db(self, session_id, entities, quote_data):
        """Save generated quote to database for tracking"""
        try:
            from src.models.chatbot import Conversation
            from src.models.user import db
            
            quote_record = Conversation(
                session_id=session_id,
                user_message=f"Wycena: {entities.get('metraz_mieszkania')} / {entities.get('pakiet_wykonczeniowy')}",
                bot_response=f"Quote generated: {quote_data['min_cost']}-{quote_data['max_cost']} zł",
                intent="wycena_konkretna",
                entities=json.dumps(quote_data, ensure_ascii=False)
            )
            
            db.session.add(quote_record)
            db.session.commit()
            
        except Exception as e:
            current_app.logger.error(f"Error saving quote to DB: {e}")


# Global instance
intent_action_handler = IntentActionHandler()

