#!/bin/bash

# NovaHouse Chatbot - Final Deployment Script
# Version 2.0 with Conversation Memory + Intent-Driven Actions

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}============================================================${NC}"
echo -e "${BLUE}   NovaHouse Chatbot - Deployment Script v2.0${NC}"
echo -e "${BLUE}   With Conversation Memory + Intent-Driven Actions${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

# Check if gcloud is installed
if ! command -v gcloud &> /dev/null; then
    echo -e "${RED}❌ gcloud CLI not found!${NC}"
    echo "Please install Google Cloud SDK first:"
    echo "https://cloud.google.com/sdk/docs/install"
    exit 1
fi

echo -e "${GREEN}✓ gcloud CLI found${NC}"

# Check authentication
echo -e "\n${YELLOW}Checking GCP authentication...${NC}"
if ! gcloud auth list --filter=status:ACTIVE --format="value(account)" | grep -q .; then
    echo -e "${RED}❌ Not authenticated with GCP${NC}"
    echo "Please run: gcloud auth login"
    exit 1
fi

ACCOUNT=$(gcloud auth list --filter=status:ACTIVE --format="value(account)")
echo -e "${GREEN}✓ Authenticated as: ${ACCOUNT}${NC}"

# Set project
PROJECT_ID="glass-core-467907-e9"
echo -e "\n${YELLOW}Setting GCP project to: ${PROJECT_ID}${NC}"
gcloud config set project ${PROJECT_ID}
echo -e "${GREEN}✓ Project set${NC}"

# Navigate to project directory
PROJECT_DIR="/home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api"
echo -e "\n${YELLOW}Navigating to project directory...${NC}"
cd ${PROJECT_DIR}
echo -e "${GREEN}✓ In directory: $(pwd)${NC}"

# Check if app.yaml exists
if [ ! -f "app.yaml" ]; then
    echo -e "${RED}❌ app.yaml not found!${NC}"
    exit 1
fi

echo -e "${GREEN}✓ app.yaml found${NC}"

# Check if requirements.txt exists
if [ ! -f "requirements.txt" ]; then
    echo -e "${RED}❌ requirements.txt not found!${NC}"
    exit 1
fi

echo -e "${GREEN}✓ requirements.txt found${NC}"

# Check new modules
echo -e "\n${YELLOW}Checking new modules...${NC}"
if [ -f "src/conversation_memory.py" ]; then
    echo -e "${GREEN}✓ conversation_memory.py found${NC}"
else
    echo -e "${RED}❌ conversation_memory.py not found!${NC}"
    exit 1
fi

if [ -f "src/intent_actions.py" ]; then
    echo -e "${GREEN}✓ intent_actions.py found${NC}"
else
    echo -e "${RED}❌ intent_actions.py not found!${NC}"
    exit 1
fi

# Show what will be deployed
echo -e "\n${BLUE}============================================================${NC}"
echo -e "${BLUE}   DEPLOYMENT SUMMARY${NC}"
echo -e "${BLUE}============================================================${NC}"
echo -e "Project: ${PROJECT_ID}"
echo -e "Service: default"
echo -e "Runtime: python311"
echo -e ""
echo -e "${GREEN}New Features:${NC}"
echo -e "  ✓ Conversation Memory (GPT context)"
echo -e "  ✓ Intent-Driven Actions (auto actions)"
echo -e ""
echo -e "${GREEN}Existing Features:${NC}"
echo -e "  ✓ AI Recommendations"
echo -e "  ✓ Sentiment Analysis"
echo -e "  ✓ Analytics Dashboard"
echo -e "  ✓ Monday.com Integration"
echo -e "  ✓ 29 Intents + 20 Entities"
echo -e "${BLUE}============================================================${NC}"
echo ""

# Ask for confirmation
read -p "Do you want to proceed with deployment? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Deployment cancelled.${NC}"
    exit 0
fi

# Deploy
echo -e "\n${YELLOW}Deploying to Google App Engine...${NC}"
echo -e "${YELLOW}This may take 5-10 minutes...${NC}"
echo ""

if gcloud app deploy app.yaml --quiet; then
    echo -e "\n${GREEN}============================================================${NC}"
    echo -e "${GREEN}   ✅ DEPLOYMENT SUCCESSFUL!${NC}"
    echo -e "${GREEN}============================================================${NC}"
    
    # Get the app URL
    APP_URL=$(gcloud app describe --format="value(defaultHostname)")
    echo -e "\n${GREEN}Application URL:${NC} https://${APP_URL}"
    
    # Test endpoints
    echo -e "\n${YELLOW}Testing endpoints...${NC}"
    
    # Test 1: Health check
    echo -e "\n${BLUE}1. Testing health check...${NC}"
    if curl -s "https://${APP_URL}/api/chatbot/health" | grep -q "healthy"; then
        echo -e "${GREEN}✓ Health check passed${NC}"
    else
        echo -e "${RED}✗ Health check failed${NC}"
    fi
    
    # Test 2: Dashboard metrics
    echo -e "\n${BLUE}2. Testing dashboard metrics...${NC}"
    if curl -s "https://${APP_URL}/api/dashboard/metrics" | grep -q "conversations"; then
        echo -e "${GREEN}✓ Dashboard metrics working${NC}"
    else
        echo -e "${RED}✗ Dashboard metrics failed${NC}"
    fi
    
    # Test 3: Recommendations
    echo -e "\n${BLUE}3. Testing AI recommendations...${NC}"
    if curl -s "https://${APP_URL}/api/recommendations/packages" | grep -q "pomarańczowy"; then
        echo -e "${GREEN}✓ AI recommendations working${NC}"
    else
        echo -e "${RED}✗ AI recommendations failed${NC}"
    fi
    
    echo -e "\n${GREEN}============================================================${NC}"
    echo -e "${GREEN}   DEPLOYMENT COMPLETE!${NC}"
    echo -e "${GREEN}============================================================${NC}"
    echo -e ""
    echo -e "${BLUE}Next steps:${NC}"
    echo -e "1. Test the chatbot in browser: https://${APP_URL}"
    echo -e "2. Test conversation memory with multiple messages"
    echo -e "3. Test intent-driven actions (meeting booking)"
    echo -e "4. Check logs: gcloud app logs tail"
    echo -e ""
    echo -e "${GREEN}🎉 Your chatbot is now live with enhanced AI features!${NC}"
    echo -e ""
    
else
    echo -e "\n${RED}============================================================${NC}"
    echo -e "${RED}   ❌ DEPLOYMENT FAILED${NC}"
    echo -e "${RED}============================================================${NC}"
    echo -e ""
    echo -e "${YELLOW}Please check the error messages above.${NC}"
    echo -e "${YELLOW}Common issues:${NC}"
    echo -e "  - Missing environment variables"
    echo -e "  - Insufficient permissions"
    echo -e "  - Invalid app.yaml configuration"
    echo -e ""
    echo -e "Check logs: gcloud app logs tail"
    exit 1
fi

