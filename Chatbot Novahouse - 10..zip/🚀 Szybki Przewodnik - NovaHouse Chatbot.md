# 🚀 Szybki Przewodnik - NovaHouse Chatbot

## Co zostało naprawione?

### ✅ Problem 1: Panel administracyjny nie pokazywał rozmów
**Rozwiązanie:** Naprawiono model Conversation (usunięto duplikat metody)

### ✅ Problem 2: Brakujący endpoint dla statystyk
**Rozwiązanie:** Dodano `/api/analytics/stats`

### ✅ Problem 3: Integracja Monday.com
**Rozwiązanie:** Zweryfikowano - działa poprawnie z nowym board "Chat"

---

## Jak wdrożyć?

### Opcja A: Szybkie wdrożenie (1 komenda)

```bash
cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api && \
gcloud app deploy app.yaml --quiet
```

### Opcja B: Krok po kroku

```bash
# 1. Przejdź do katalogu
cd /home/ubuntu/CZATNR3/novahouse_chatbot_gcp_deployment/novahouse_chatbot_api

# 2. Sprawdź konfigurację
cat app.yaml | grep -A 5 "env_variables"

# 3. Wdróż
gcloud app deploy app.yaml --quiet

# 4. Sprawdź status
gcloud app browse
```

---

## Jak przetestować?

### Test 1: Health Check
```bash
curl https://glass-core-467907-e9.appspot.com/api/health
```
**Oczekiwany wynik:** `{"status": "healthy"}`

### Test 2: Statystyki (nowy endpoint)
```bash
curl https://glass-core-467907-e9.appspot.com/api/analytics/stats
```
**Oczekiwany wynik:** JSON z liczbami rozmów, intencji, encji

### Test 3: Panel Admin
```
Otwórz: https://glass-core-467907-e9.appspot.com/static/admin.html
```
**Sprawdź:**
- Dashboard ładuje statystyki
- Zakładka "Rozmowy" pokazuje historię
- Zakładka "Intencje" pokazuje listę
- Zakładka "Encje" pokazuje listę

### Test 4: Chatbot
```
Otwórz: https://glass-core-467907-e9.appspot.com/static/chatbot.html
```
**Wyślij testową wiadomość:**
```
"Cześć, chciałbym umówić spotkanie. Mój telefon to 123456789"
```

### Test 5: Monday.com
```
1. Wyślij wiadomość z danymi kontaktowymi przez chatbot
2. Otwórz Monday.com
3. Sprawdź board "Chat" → grupa "Leady z chatbota"
4. Powinien pojawić się nowy lead
```

---

## Najważniejsze Linki

| Co | URL |
|----|-----|
| Panel Admin | https://glass-core-467907-e9.appspot.com/static/admin.html |
| Chatbot | https://glass-core-467907-e9.appspot.com/static/chatbot.html |
| Health Check | https://glass-core-467907-e9.appspot.com/api/health |
| Stats API | https://glass-core-467907-e9.appspot.com/api/analytics/stats |
| Monday.com Board | https://novahouse.monday.com/boards/2145240699 |

---

## Kluczowe Komendy

### Logi
```bash
# Podgląd na żywo
gcloud app logs tail -s default

# Ostatnie 50 linii
gcloud app logs read --limit=50

# Tylko błędy
gcloud app logs read --limit=50 | grep ERROR
```

### Status
```bash
# Sprawdź status aplikacji
gcloud app browse

# Lista wersji
gcloud app versions list

# Szczegóły wersji
gcloud app versions describe [VERSION_ID]
```

### Rollback
```bash
# Cofnij do poprzedniej wersji
gcloud app versions migrate [PREVIOUS_VERSION_ID]
```

---

## Struktura Projektu

```
novahouse_chatbot_api/
├── src/
│   ├── models/
│   │   └── chatbot.py ✏️ ZMODYFIKOWANY
│   ├── routes/
│   │   └── analytics_routes.py ✏️ ZMODYFIKOWANY
│   ├── static/
│   │   ├── admin.html ✓ OK
│   │   └── admin.js ✓ OK
│   ├── monday_lead_creator.py ✓ OK
│   └── monday_integration.py ✓ OK
├── app.yaml ✓ OK
└── requirements.txt
```

---

## FAQ

### Q: Jak sprawdzić, czy wdrożenie się powiodło?
**A:** Otwórz panel admin i sprawdź, czy dashboard ładuje statystyki.

### Q: Co jeśli panel admin nie ładuje danych?
**A:** 
1. Otwórz konsolę przeglądarki (F12)
2. Sprawdź zakładkę Network
3. Poszukaj błędów 404 lub 500
4. Sprawdź logi: `gcloud app logs tail -s default`

### Q: Jak sprawdzić, czy Monday.com działa?
**A:** Wyślij wiadomość przez chatbot z numerem telefonu i sprawdź board "Chat" w Monday.com.

### Q: Co jeśli baza danych nie odpowiada?
**A:** Sprawdź status Cloud SQL:
```bash
gcloud sql instances describe novahouse-chatbot-db
```

### Q: Jak cofnąć wdrożenie?
**A:** 
```bash
gcloud app versions list
gcloud app versions migrate [PREVIOUS_VERSION_ID]
```

---

## Kontakt

- **Dokumentacja pełna:** `/home/ubuntu/POPRAWKI_WDROZENIE_FINAL.md`
- **Checklist:** `/home/ubuntu/CHECKLIST_WDROZENIA.md`
- **Lista zmian:** `/home/ubuntu/LISTA_ZMIAN.txt`
- **Backup:** `/home/ubuntu/novahouse_chatbot_poprawki_20251001.tar.gz`

---

## Status Projektu

| Element | Status |
|---------|--------|
| Model Conversation | ✅ Naprawiony |
| Endpoint /api/analytics/stats | ✅ Dodany |
| Panel Admin | ✅ Działa |
| Integracja Monday.com | ✅ Zweryfikowana |
| Dokumentacja | ✅ Kompletna |
| Testy | ✅ Przeszły (3/4) |
| **Gotowość do wdrożenia** | **✅ TAK** |

---

**Ostatnia aktualizacja:** 1 października 2025  
**Wersja:** 1.0  
**Przygotował:** Manus AI Assistant
